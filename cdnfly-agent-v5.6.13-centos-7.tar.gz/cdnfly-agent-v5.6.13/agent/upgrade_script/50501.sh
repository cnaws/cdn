#!/bin/bash

set -o errexit

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

start_on_boot(){
    local cmd="$1"
    if [[ -f "/etc/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.local
        if [[ `grep "${cmd}" /etc/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.local
        fi 
        chmod +x /etc/rc.local
    fi


    if [[ -f "/etc/rc.d/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.d/rc.local
        if [[ `grep "${cmd}" /etc/rc.d/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.d/rc.local
        fi 
        chmod +x /etc/rc.d/rc.local 
    fi 
}


#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}

force_restart() {
    now_time=`date +%s`
    echo $now_time > /tmp/monitor_restart.time
    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf stop task
    ok=`/usr/local/openresty/nginx/sbin/nginx -t 2>&1 | grep "syntax is ok" || true`
    if [[ $ok == "" ]];then
        echo "nginx config error"
        exit 1
    fi
        
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
    sleep 2
    rm -f /var/run/nginx.sock
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx
}

upgrade_cmd() {

# 更新攻击页面
cat > /tmp/_db.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
sys.path.append("/opt/cdnfly/agent/")
from conf.config import ES_PWD
import json
reload(sys) 
import os
sys.setdefaultencoding('utf8')


if os.path.exists("/usr/local/openresty/nginx/conf/vhost/openresty.json"):
    with open("/usr/local/openresty/nginx/conf/vhost/openresty.json") as fp:
        data = fp.read()

    openresty = json.loads(data)
    openresty['slider_html'] = "<!DOCTYPE html>\n<html>\n<head>\n<title>拖动验证</title>\n<meta charset='utf-8'/>\n<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'>\n<meta name='apple-mobile-web-app-capable' content='yes'>\n<meta name='apple-mobile-web-app-status-bar-style' content='black'>\n<meta name='format-detection' content='telephone=no'>\n<link rel='stylesheet' href='https://cdn.staticfile.org/twitter-bootstrap/3.3.4/css/bootstrap.min.css'>\n<style type='text/css'>\n.stage{position:relative;padding: 0 15px;height:55px;}\n.slider{position:absolute;height:52px;box-shadow:0 0 3px #999;background-color:#ddd;left:15px;right:15px;}\n.tips {\n    background: -webkit-gradient(linear, left top, right top, color-stop(0, #4d4d4d), color-stop(.4, #4d4d4d), color-stop(.5, white), color-stop(.6, #4d4d4d), color-stop(1, #4d4d4d));\n    -webkit-background-clip: text;\n    -webkit-text-fill-color: transparent;\n    -webkit-animation: slidetounlock 3s infinite;\n    -webkit-text-size-adjust: none;\n    line-height: 52px;\n    height: 52px;\n    text-align: center;\n    font-size: 16px;\n    width: 100%;\n    color: #aaa;\n}\n\n@media screen and (max-width: 560px) { \n.main {max-width:100%;font-size: 16px;} \n} \n\n@keyframes slidetounlock\n{\n    0%     {background-position:-200px 0;}\n    100%   {background-position:200px 0;}\n}\n@-webkit-keyframes slidetounlock\n{\n    0%     {background-position:-200px 0;}\n    100%   {background-position:200px 0;}\n}\n.button{\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 52px;\n    height: 52px;\n    background-color: #fff;\n    transition: left 0s;\n    -webkit-transition: left 0s;\n}\n.button-on{\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 52px;\n    height: 52px;\n    background-color: #fff;\n    transition: left 1s;\n    -webkit-transition: left .5s;\n}\n.track{\n    position: absolute;\n    left: 0;\n    top: 0;\n    height: 100%;\n    width: 0;\n    overflow: hidden;\n    transition: width 0s;\n    -webkit-transition: width 0s;\n}\n.track-on{\n    position: absolute;\n    left: 0;\n    top: 0;\n    height: 100%;\n    width: 0;\n    overflow: hidden;\n    transition: width 1s;\n    -webkit-transition: width .5s;\n}\n.icon  {\n    width: 32px;\n    height: 32px;\n    position: relative;\n    top:10px;\n    left:20px;\n    font-family: sans-serif;\n}\n.icon:before{\n    content:'>>';\n    color:#ccc;\n    line-height:32px;\n}\n.spinner {\n    width: 32px;\n    height: 32px;\n        background: url('data:image/png;base64,jwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAQMSURBVFhHzZdLbFRlFMf/82g7LYPQDlDQaZTQR7QlERVoN6Q1UXdqVChrWUDCohtDUqJViQFW+FywAV0ykGhi4sImWuqmDTXaGDChlABhkBlK26lMpzPMy/P/vnsvc+fFtCPiL2nvfN+99/zPPed7nM+RFfAYcRrXx8ayInB36QYuhL7FlcgYQrEriKcWVb/HvQobG9rQ1tiDHc1vYV3906q/Eipy4NLsTwhMvY+ZpevwuFbB5ayFy+GWOw79ALJIZ1NIZe4jkV7E+vrN6G//BJ2+l437pSnrAG8dm3gVwegleGua4BRRh8MULQ7fyYgz0eQc/N5ODG4fLvtOSQfCsav4eHwXGtxPoMblMXqXRzIdx1Lqbwx1/4Lmhi1Gr52igzAcm8bQWA9W1/pWLE74rlds0BZtFqMgAmweHPErcafDZfRWRyabVin5qvdmQToKIsCcM+zVivNDkpmEutJWvWu12H7NuPsAmwMc7Rxw1YSdUDSanMWzjbsQSy2oNm0GoxdF42fjKY3NgcDUB2q0VwPFIonbeLv1I+zrOon3Xvwei6l5dY+2z8p0zsVygHN8ZumammorRYv/hf6Oo+hr2af6YsmIrBZahrbviAa1TCwHuMJxkXnYPC+FKb634zj6/Fr8z9kRnPjtTRlTa1SbtutEYyL8nWoTy4HpyLha4VaCGfb+jmPo9b+r+pjrzyb3oMnTYvsot2hMz48brRwHQjJP9fKqoVFOnUUJIX+XwhJvl7AbX07xLyb70VT3VEFEqXFb9hETy4F4+p781w/TaCwVwaGXfsCBrV9jLh4s6oQWt+ecYf9cvryxiLjGYWhpLAdyScn8fWHD62jxduE5Xy8Gtp3DXOKWzQlTPD/nn/7+jny5v+KxZDngkYVCzKrfbmcdfpWBMhI8pdqdvj4MPB+QSGgntHjxnPvycl5I1tDSWA5sbGhVWyqhAW+ND4HLgzgfPK36uLUObDur0jHPsFeY83yosUlqBxPLgba1PUjLfm5CQ2vrnsQZmxN92L/1FN7YMriMnNthzdDa2G20REfCqeLOxYG71praZpshM9cMt/nFJmbOHx52DW0t3A/jSM+YFC3PqD4rAuzgH4uJXMxIBC4ftsYEqTznD6DtDVItmeLENgv2SBnFuZ+PdmKTcmI0+A3+uDuMLyf3VpTzXGibGrkU1ANHL7yiBlqxHZGPxtNRuWZQL1v2csRZHXFVPLxj2OjR/P8KEj7wYfeoDLyQerFaaGMhEcbQzvNFI/boi1JZdod2jpYsSks6QHirurK8S8ryH8u+U9YBk4sy5VjJsGDhfs4ttdzBhFNtt4z2rmoPJvnMyNFsIixHM9nPQ7GpvKNZuxzNurFdjmbr/+2j2aOkYBb8twD/APBmN4ba5Vu7AAAAAElFTkSuQmCC') no-repeat;\n    position: relative;\n    top:10px;\n    left:10px;\n    display: none;\n}\n\n@-webkit-keyframes bouncedelay {\n    0%, 80%, 100% { -webkit-transform: scale(0.0) }\n    40% { -webkit-transform: scale(1.0) }\n}\n@keyframes bouncedelay {\n    0%, 80%, 100% {\n        transform: scale(0.0);\n        -webkit-transform: scale(0.0);\n    } 40% {\n          transform: scale(1.0);\n          -webkit-transform: scale(1.0);\n      }\n}\n.bg-green {\n    line-height: 52px;\n    height: 52px;\n    text-align: center;\n    font-size: 16px;\n    background-color: #78c430;\n}\nbody{ margin:auto; padding:0;font-family: 'Microsoft Yahei',Hiragino Sans GB, WenQuanYi Micro Hei, sans-serif; background:#f9f9f9}\n.main{width:560px;margin:auto; margin-top:140px}\n.panel-footer{ text-align: center}\n.txts{ text-align:center; margin-top:40px}\n.bds{ line-height:40px; border-left:#CCC 1px solid; padding-left:20px}\n.panel{ margin-top:30px}\n</style>\n<script>\nwindow.onerror = function(message, url, lineNumber, columnNumber, error) {\n  alert(`捕获到全局异常: ${message}\n在 ${url}: 第${lineNumber}行, 第${columnNumber}列`);\n  return true;\n};\nvar translations = {\n    'CN': {\n        'warning': '网站当前访问量较大，请拖动滑块后继续访问',\n        'access': '向右滑动验证',\n        'title': '拖动验证'\n    },\n    'US': {\n        'warning': 'The website is currently experiencing high traffic. Please drag the slider to continue accessing the site.',\n        'access': 'Slide to the right to verify.',\n        'title': 'Drag to verify'\n    }\n    // ... 可以添加其他语言翻译\n};\n\nfunction setLanguage(langCode) {\n    if (!translations[langCode]) {\n        langCode = 'CN'; // 默认语言，如果没有找到合适的翻译\n    }\n\n    document.querySelector('#warning').innerText = translations[langCode]['warning'];\n    document.querySelector('.tips').innerText = translations[langCode]['access'];\n    document.querySelector('title').innerText = translations[langCode]['title'];\n}\n\n// 当页面加载时设置语言\nwindow.onload = function() {\n    var areacode = '{areacode}'; // 在实际应用中，需要从服务器或其他来源获取此值\n    setLanguage(areacode);\n};\n</script>\n\n</head>\n\n<body>\n  <div class='main'>\n<div class='alert alert-success' role='alert'>\n  <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>\n  <span class='sr-only'>Error:</span>\n   <span id='warning'>网站当前访问量较大，请拖动滑块后继续访问</span>\n</div>\n<form class='form-inline'>\n<div class='panel panel-success'>\n  <div class='panel-body'>\n  <div class='row'>\n<div class='stage'>\n    <div class='slider' id='slider'>\n      <div class='tips'>向右滑动验证</div>\n      <div class='track' id='track'>\n        <div class='bg-green'></div>\n      </div>\n      <div class='button' id='btn'>\n        <div class='icon' id='icon'></div>\n        <div class='spinner' id='spinner'></div>\n      </div>\n    </div>\n</div>\n</div>\n</div>\n</div>\n</form>\n</div>\n<script type='text/javascript' src='/_guard/slide.js'></script>\n\n</body>\n</html>"
    openresty['captcha_html'] = "<html lang='zh-CN'>\n<head>\n<meta charset='utf-8'>\n<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'>\n<meta name='apple-mobile-web-app-capable' content='yes'>\n<meta name='apple-mobile-web-app-status-bar-style' content='black'>\n<meta name='format-detection' content='telephone=no'>\n<title>输入验证码访问</title>\n<link rel='stylesheet' href='//apps.bdimg.com/libs/bootstrap/3.3.4/css/bootstrap.min.css'>\n<script type='text/javascript' src='//apps.bdimg.com/libs/jquery/1.7.2/jquery.min.js'></script>\n<style>\nbody{ margin:auto; padding:0;font-family: 'Microsoft Yahei',Hiragino Sans GB, WenQuanYi Micro Hei, sans-serif; background:#f9f9f9}\n.main{width:560px;margin:auto; margin-top:140px}\n@media screen and (max-width: 560px) { \n.main {max-width:100%;} \n} \n.panel-footer{ text-align: center}\n.txts{ text-align:center; margin-top:40px}\n.bds{ line-height:40px; border-left:#CCC 1px solid; padding-left:20px}\n.panel{ margin-top:30px}\n</style>\n<!--[if lt IE 9]>\n<style>\n.row\n{\n    height: 100%;\n    display: table-row;\n}\n.col-md-3\n{\n    display: table-cell;\n}\n\n.col-md-9\n{\n    display: table-cell;\n}\n</style>\n<![endif]-->\n\n<script>\nwindow.onerror = function(message, url, lineNumber, columnNumber, error) {\n  alert(`捕获到全局异常: ${message}\n在 ${url}: 第${lineNumber}行, 第${columnNumber}列`);\n  return true;\n};\n\nvar translations = {\n    'CN': {\n        'warning': '网站当前访问量较大，请输入验证码后继续访问',\n        'access': '进入网站',\n        'title': '输入验证码访问',\n        'tip1': '请输入验证码',\n        'tip2': '请输入图片中的验证码，不区分大小写',\n        'tip3': '换一个'\n    },\n    'US': {\n    'warning': 'The website is currently experiencing high traffic. Please enter the captcha to continue accessing the site.',\n    'access': 'Enter Website',\n    'title': 'Enter Captcha to Access',\n    'tip1': 'Please enter the captcha',\n    'tip2': 'Please enter the captcha from the image, case insensitive',\n    'tip3': 'Switch'\n    },\n    // ... 可以添加其他语言翻译\n};\n\nfunction setLanguage(langCode) {\n    if (!translations[langCode]) {\n        langCode = 'CN'; // 默认语言，如果没有找到合适的翻译\n    }\n\n    document.querySelector('.warning').innerText = translations[langCode]['warning'];\n    document.querySelector('title').innerText = translations[langCode]['title'];\n    document.querySelector('.tip1').innerText = translations[langCode]['tip1'];\n    document.querySelector('.tip2').innerText = translations[langCode]['tip2'];\n    document.querySelector('.tip3').innerText = translations[langCode]['tip3'];\n    document.querySelector('#access').innerText = translations[langCode]['access'];\n\n}\n\n// 当页面加载时设置语言\nwindow.onload = function() {\n    var areacode = '{areacode}'; // 在实际应用中，需要从服务器或其他来源获取此值\n    setLanguage(areacode);\n};\n</script>\n\n</head>\n\n<body>\n<div class='main'>\n<div class='alert alert-success' role='alert'>\n  <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>\n  <span class='sr-only'>Error:</span>\n  &nbsp;<span class='warning'>网站当前访问量较大，请输入验证码后继续访问</span>\n</div>\n<div class='panel panel-success'>\n  <div class='panel-body'>\n  <div class='row'>\n  <div class='col-md-3'><div class='txts tip1'>请输入验证码</div></div>\n  <div class='col-md-9'>\n  <div class='bds row'>\n  <span class='tip2'>请输入图片中的验证码，不区分大小写</span><br>\n  <input type='text' name='response' class='form-control' id='response'  style='width:40%;display:inline;'>&nbsp;\n  <span style='width:60px' id='captcha' class='yz'  alt='Captcha image'><img src='#' class='captcha-code'></span>&nbsp;<span><a class='refresh-captcha-code tip3'>换一个</a></span>\n  <p><span style='color:red' id='notice'></span></p>\n  </div>\n  </div>\n  </div> \n  </div>\n   <div class='panel-footer'><button type='button' id='access' class='btn btn-success'>进入网站</button> </div>\n</div>\n</div>\n<script language='javascript' type='text/javascript'>\n    $('.captcha-code').attr('src','/_guard/captcha.png?r=' + Math.random());\n\n    $('.refresh-captcha-code').click(function() {\n        $('.captcha-code').attr('src','/_guard/captcha.png?r=' + Math.random());\n    });\n\n    $('#access').click(function(e){\n      var response = $('#response').val();\n      document.cookie = 'guardret='+response\n      \n      window.location.reload();\n    });\n\n</script>\n</body>\n</html>"
    openresty['click_html'] = "<html lang='zh-CN'>\n<head>\n<meta charset='utf-8'>\n<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'>\n<meta name='apple-mobile-web-app-capable' content='yes'>\n<meta name='apple-mobile-web-app-status-bar-style' content='black'>\n<meta name='format-detection' content='telephone=no'>\n<title>点击验证</title>\n<style>\nbody{ margin:auto; padding:0;font-family: 'Microsoft Yahei',Hiragino Sans GB, WenQuanYi Micro Hei, sans-serif; background:#f9f9f9}\n.main{width:460px;margin:auto; margin-top:140px}\n@media screen and (max-width: 560px) { \n.main {max-width:100%;} \n} \n.alert {text-align:center}\n.panel-footer{ text-align: center}\n.txts{ text-align:center; margin-top:40px}\n.bds{ line-height:40px; border-left:#CCC 1px solid; padding-left:20px}\n.panel{ margin-top:30px}\n.alert-success {\n    color: #3c763d;\n    background-color: #dff0d8;\n    border-color: #d6e9c6;\n}\n.alert {\n    padding: 15px;\n    margin-bottom: 20px;\n    border: 1px solid transparent;\n    border-radius: 4px;\n}\n.glyphicon {\n    position: relative;\n    top: 1px;\n    display: inline-block;\n    font-family: 'Glyphicons Halflings';\n    font-style: normal;\n    font-weight: 400;\n    line-height: 1;\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n}\n.btn-success {\n    color: #fff;\n    background-color: #5cb85c;\n    border-color: #4cae4c;\n}\n.btn {\n    display: inline-block;\n    padding: 6px 12px;\n    margin-bottom: 0;\n    font-size: 14px;\n    font-weight: 400;\n    line-height: 1.42857143;\n    text-align: center;\n    white-space: nowrap;\n    vertical-align: middle;\n    -ms-touch-action: manipulation;\n    touch-action: manipulation;\n    cursor: pointer;\n    -webkit-user-select: none;\n    -moz-user-select: none;\n    -ms-user-select: none;\n    user-select: none;\n    background-image: none;\n    border: 1px solid transparent;\n    border-radius: 4px;\n}\n</style>\n<!--[if lt IE 9]>\n<style>\n.row\n{\n    height: 100%;\n    display: table-row;\n}\n.col-md-3\n{\n    display: table-cell;\n}\n.col-md-9\n{\n    display: table-cell;\n}\n</style>\n<![endif]-->\n<script>\nwindow.onerror = function(message, url, lineNumber, columnNumber, error) {\n  alert(`捕获到全局异常: ${message}\n在 ${url}: 第${lineNumber}行, 第${columnNumber}列`);\n  return true;\n};\nvar translations = {\n    'CN': {\n        'warning': '网站当前访问量较大，请点击按钮继续访问',\n        'access': '进入网站'\n    },\n    'US': {\n        'warning': 'The website is currently experiencing high traffic. Please click the button to continue accessing.',\n        'access': 'Enter the Website'\n    }\n    // ... 可以添加其他语言翻译\n};\n\nfunction setLanguage(langCode) {\n    if (!translations[langCode]) {\n        langCode = 'CN'; // 默认语言，如果没有找到合适的翻译\n    }\n\n    document.querySelector('.alert span:nth-child(2)').innerText = translations[langCode]['warning'];\n    document.querySelector('#access').innerText = translations[langCode]['access'];\n}\n\n// 当页面加载时设置语言\nwindow.onload = function() {\n    var areacode = '{areacode}'; // 在实际应用中，需要从服务器或其他来源获取此值\n    setLanguage(areacode);\n};\n</script>\n\n</head>\n<body>\n<div class='main'>\n<div class='alert alert-success' role='alert'>\n  <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>\n  <span style='font-size: 15px;'> 网站当前访问量较大，请点击按钮继续访问</span><br>\n    <button style='margin-top: 20px;' id='access' class='btn btn-success'>进入网站</button>\n</div>\n</div>\n<script type='text/javascript' src='/_guard/click.js'></script>\n</body>\n</html>"
    openresty['delay_jump_html'] = "<html lang='zh-CN'>\n<head>\n<meta charset='utf-8'>\n<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'>\n<meta name='apple-mobile-web-app-capable' content='yes'>\n<meta name='apple-mobile-web-app-status-bar-style' content='black'>\n<meta name='format-detection' content='telephone=no'>\n<title>浏览器检查中...</title>\n<style>\nbody{ margin:auto; padding:0;font-family: 'Microsoft Yahei',Hiragino Sans GB, WenQuanYi Micro Hei, sans-serif; background:#f9f9f9}\n.main{width:460px;margin:auto; margin-top:140px}\n@media screen and (max-width: 560px) { \n.main {max-width:100%;} \n} \n#second {color:red;}\n.alert {text-align:center}\n.panel-footer{ text-align: center}\n.txts{ text-align:center; margin-top:40px}\n.bds{ line-height:40px; border-left:#CCC 1px solid; padding-left:20px}\n.panel{ margin-top:30px}\n.alert-success {\n    color: #3c763d;\n    background-color: #dff0d8;\n    border-color: #d6e9c6;\n}\n.alert {\n    padding: 15px;\n    margin-bottom: 20px;\n    border: 1px solid transparent;\n    border-radius: 4px;\n}\n.glyphicon {\n    position: relative;\n    top: 1px;\n    display: inline-block;\n    font-family: 'Glyphicons Halflings';\n    font-style: normal;\n    font-weight: 400;\n    line-height: 1;\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n}\n</style>\n<!--[if lt IE 9]>\n<style>\n.row\n{\n    height: 100%;\n    display: table-row;\n}\n.col-md-3\n{\n    display: table-cell;\n}\n\n.col-md-9\n{\n    display: table-cell;\n}\n</style>\n<![endif]-->\n\n<script>\nwindow.onerror = function(message, url, lineNumber, columnNumber, error) {\n  alert(`捕获到全局异常: ${message}\n在 ${url}: 第${lineNumber}行, 第${columnNumber}列`);\n  return true;\n};\nvar translations = {\n    'CN': {\n        'tip1': '浏览器安全检查中，系统将在',\n        'tip2': '秒后返回网站',\n        'title': '浏览器检查中...'\n    },\n    'US': {\n        'tip1': 'Browser security check in progress, the system will return to the website in ',\n        'tip2': ' seconds',\n        'title': 'Browser Checking...'\n    }\n    // ... 可以添加其他语言翻译\n};\n\nfunction setLanguage(langCode) {\n    if (!translations[langCode]) {\n        langCode = 'CN'; // 默认语言，如果没有找到合适的翻译\n    }\n\n    document.querySelector('.tip1').innerText = translations[langCode]['tip1'];\n    document.querySelector('.tip2').innerText = translations[langCode]['tip2'];\n    document.querySelector('title').innerText = translations[langCode]['title'];\n}\n\n// 当页面加载时设置语言\nwindow.onload = function() {\n    var areacode = '{areacode}'; // 在实际应用中，需要从服务器或其他来源获取此值\n    setLanguage(areacode);\n};\n</script>\n\n\n</head>\n\n<body>\n<div class='main'>\n<div class='alert alert-success' role='alert'>\n  <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>\n  <span style='font-size: 15px;'><span class='tip1'>浏览器安全检查中，系统将在</span><span id='second'>5</span><span class='tip2'>秒后返回网站</span></span>\n</div>\n\n</div>\n<script type='text/javascript' src='/_guard/delay_jump.js'></script>\n</body>\n</html>"
    openresty['rotate_html'] = "<html>\n<head>\n<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\n<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no'>\n<title>旋转图片验证</title>\n</head>\n<script>\nwindow.onerror = function(message, url, lineNumber, columnNumber, error) {\n  alert(`捕获到全局异常: ${message}\n在 ${url}: 第${lineNumber}行, 第${columnNumber}列`);\n  return true;\n};\nvar translations = {\n    'CN': {\n        'desc': '拖动滑块，使图片角度为正',\n        'title': '旋转图片验证'\n    },\n    'US': {\n        'desc': 'Drag the slider to rotate the image to the upright position',\n        'title': 'Rotate Image Verification'\n    }\n    // ... 可以添加其他语言翻译\n};\n\nfunction setLanguage(langCode) {\n    if (!translations[langCode]) {\n        langCode = 'CN'; // 默认语言，如果没有找到合适的翻译\n    }\n\n    document.querySelector('title').innerText = translations[langCode]['title'];\n}\n\n// 当页面加载时设置语言\nwindow.onload = function() {\n    var areacode = '{areacode}'; // 在实际应用中，需要从服务器或其他来源获取此值\n    setLanguage(areacode);\n};\n</script>\n\n<body>\n<style>\n@media screen and (max-width: 305px) { \n.captcha-root {max-width:100%;font-size: 16px;} \n} \n</style>\n<div class='J__captcha__'></div>\n<script src='/_guard/rotate.js'></script>\n<script>\nvar areacode = '{areacode}';\nif (!translations[areacode]) {\n    areacode = 'CN'; // 默认语言，如果没有找到合适的翻译\n}\n\nlet myCaptcha = document.querySelectorAll('.J__captcha__').item(0).captcha({\n  // 验证成功时显示\n  timerProgressBar: !0, // 是否启用进度条\n  timerProgressBarColor: '#07f', // 进度条颜色\n  title: translations[areacode]['title'],\n  desc: translations[areacode]['desc']  \n});\n</script>\n</body>\n</html>"

    with open("/usr/local/openresty/nginx/conf/vhost/openresty.json","w") as fp:
        fp.write(json.dumps(openresty))


if os.path.exists("/usr/local/openresty/nginx/conf/vhost/acl.json"):
    with open("/usr/local/openresty/nginx/conf/vhost/acl.json") as fp:
        data = fp.read()

    data_json = json.loads(data)
    for site_id in data_json:
        data_json[site_id]['reject_code'] = "403"
        data_json[site_id]['redirect_url'] = ""
        acl_data = data_json[site_id]['acl_data']
        for i in range(len(acl_data)):
            acl_data[i]['acl_code'] = "403"
            acl_data[i]['acl_url'] = ""

        data_json[site_id]['acl_data'] = acl_data


    with open("/usr/local/openresty/nginx/conf/vhost/acl.json","w") as fp:
        fp.write(json.dumps(data_json))

EOF

/opt/venv/bin/python /tmp/_db.py

}

update_file() {
cd /opt/$dir_name/
for i in `find ./ | grep -vE "conf/config.py|/nginx/conf/captcha/|/nginx/conf/rotate/|conf/filebeat.yml|^./agent/conf$|^./$|^./agent$"`;do
    \cp -aT $i /opt/cdnfly/$i
done

}


# 定义版本
version_name="v5.5.1"
version_num="50501"
dir_name="cdnfly-agent-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

###########
echo "执行升级命令..."
upgrade_cmd
echo "执行升级命令完成"
###########

echo "更新文件..."
update_file
echo "更新文件完成."

echo "开始重启agent..."

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/agent/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/agent/conf/config.py
rm -f /opt/cdnfly/agent/conf/config.pyc
echo "修改完成"

rm -f /opt/cdnfly/agent/conf/config.pyc
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task
#supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart filebeat

# 重载nginx
ps aux  | grep [/]usr/local/openresty/nginx/sbin/nginx | awk '{print $2}' | xargs kill -HUP || true

# 重启nginx
#force_restart

echo "重启完成"

echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"



