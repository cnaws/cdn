#!/bin/bash

set -o errexit

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

start_on_boot(){
    local cmd="$1"
    if [[ -f "/etc/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.local
        if [[ `grep "${cmd}" /etc/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.local
        fi 
        chmod +x /etc/rc.local
    fi


    if [[ -f "/etc/rc.d/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.d/rc.local
        if [[ `grep "${cmd}" /etc/rc.d/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.d/rc.local
        fi 
        chmod +x /etc/rc.d/rc.local 
    fi 
}


#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}

force_restart() {
    now_time=`date +%s`
    echo $now_time > /tmp/monitor_restart.time
    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf stop task
    ok=`/usr/local/openresty/nginx/sbin/nginx -t 2>&1 | grep "syntax is ok" || true`
    if [[ $ok == "" ]];then
        echo "nginx config error"
        exit 1
    fi
        
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
    sleep 2
    rm -f /var/run/nginx.sock
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx
}

upgrade_cmd() {
# openresty.json文件，更新spider ip
cat > /tmp/_db.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
sys.path.append("/opt/cdnfly/agent/")
from conf.config import ES_PWD
import json
reload(sys) 
import os
sys.setdefaultencoding('utf8')
import re
import subprocess


if os.path.exists("/usr/local/openresty/nginx/conf/vhost/openresty.json"):
    with open("/usr/local/openresty/nginx/conf/vhost/openresty.json") as fp:
        data = fp.read()

    openresty = json.loads(data)
    openresty['spider_ip'] = {"40.77.195": 1, "40.77.194": 1, "40.77.191": 1, "40.77.190": 1, "40.77.193": 1, "40.77.192": 1, "34.89.10": 1, "154.12.224.26": 1, "220.243.189": 1, "220.243.188": 1, "40.77.168": 1, "40.77.169": 1, "40.77.160": 1, "123.183.224": 1, "40.77.162": 1, "40.77.163": 1, "40.77.164": 1, "40.77.165": 1, "40.77.166": 1, "40.77.167": 1, "34.88.194": 1, "20.36.108": 1, "34.65.242": 1, "217.156.87.14": 1, "157.55.50": 1, "40.90.149": 1, "40.90.148": 1, "40.90.147": 1, "40.90.146": 1, "40.90.145": 1, "40.90.144": 1, "65.55.230.252": 1, "51.4.84": 1, "65.55.230.250": 1, "40.77.223": 1, "40.77.222": 1, "40.77.221": 1, "40.77.220": 1, "34.64.82": 1, "218.30.103": 1, "23.103.64": 1, "65.54.164": 1, "207.68.185.33": 1, "40.77.161": 1, "199.30.28": 1, "106.11.157": 1, "106.11.156": 1, "106.11.155": 1, "106.11.154": 1, "106.11.153": 1, "106.11.152": 1, "207.46.13": 1, "193.234.60.18": 1, "106.11.159": 1, "106.11.158": 1, "109.238.6.49": 1, "109.238.6.46": 1, "61.135.158.81": 1, "220.243.136": 1, "220.243.135": 1, "40.79.186": 1, "217.156.87.5": 1, "110.249.201": 1, "110.249.202": 1, "131.253.46.111": 1, "106.120.188.69": 1, "40.90.11": 1, "42.120.236": 1, "42.159.48": 1, "34.154.114": 1, "199.30.30": 1, "199.30.31": 1, "202.89.235": 1, "111.206.221": 1, "42.120.161": 1, "104.44.93": 1, "104.44.92": 1, "104.44.91": 1, "64.4.22": 1, "36.110.147.71": 1, "36.110.147.70": 1, "157.55.154": 1, "42.236.46": 1, "157.56.93": 1, "123.125.125.179": 1, "42.236.49": 1, "65.55.189": 1, "199.188.107.107": 1, "131.253.35": 1, "157.56.71": 1, "34.146.150": 1, "61.135.169.52": 1, "61.135.169.53": 1, "178.20.236": 1, "61.135.168": 1, "113.24.225": 1, "40.77.253": 1, "40.77.186": 1, "40.77.187": 1, "40.77.184": 1, "40.77.185": 1, "40.77.182": 1, "40.77.183": 1, "40.77.180": 1, "40.77.181": 1, "40.77.188": 1, "40.77.189": 1, "42.236.101": 1, "42.236.102": 1, "42.236.103": 1, "20.74.197": 1, "61.135.169.19": 1, "34.118.254": 1, "20.15.133": 1, "207.46.126": 1, "65.52.109": 1, "131.253.46.223": 1, "157.56.2": 1, "157.56.3": 1, "157.56.0": 1, "157.56.1": 1, "20.43.120": 1, "34.100.182": 1, "40.77.248": 1, "40.90.150": 1, "40.90.151": 1, "40.90.152": 1, "40.90.153": 1, "40.90.154": 1, "40.90.155": 1, "40.90.156": 1, "40.90.157": 1, "40.90.158": 1, "42.120.234": 1, "42.120.235": 1, "111.221.28": 1, "61.135.165.19": 1, "49.7.116": 1, "49.7.117": 1, "40.90.8": 1, "207.68.176.142": 1, "207.68.176.141": 1, "118.184.177": 1, "66.249.79": 1, "66.249.78": 1, "66.249.71": 1, "66.249.70": 1, "66.249.73": 1, "66.249.72": 1, "66.249.75": 1, "66.249.74": 1, "66.249.77": 1, "66.249.76": 1, "191.232.136.48": 1, "60.8.123": 1, "180.76.15": 1, "191.232.136.172": 1, "43.231.99": 1, "207.68.146.215": 1, "61.135.159": 1, "131.253.46.125": 1, "131.253.46.126": 1, "35.247.243": 1, "34.165.18": 1, "65.54.247": 1, "40.66.1": 1, "180.153.232": 1, "40.66.4": 1, "51.5.84": 1, "34.175.160": 1, "123.125.186.11": 1, "123.125.186.12": 1, "34.152.50": 1, "40.77.209": 1, "40.77.208": 1, "42.159.176": 1, "220.181.108": 1, "65.55.230.225": 1, "61.135.165.53": 1, "103.255.141": 1, "42.236.48": 1, "154.12.224.161": 1, "157.55.39": 1, "191.232.136.86": 1, "65.55.230.253": 1, "180.76.5": 1, "36.110.147.68": 1, "36.110.147.69": 1, "193.234.60.17": 1, "40.77.210": 1, "111.206.198": 1, "36.110.147.64": 1, "36.110.147.65": 1, "36.110.147.66": 1, "36.110.147.67": 1, "42.120.160": 1, "192.178.5": 1, "123.126.113": 1, "131.253.36": 1, "42.236.99": 1, "103.25.156": 1, "123.125.125.184": 1, "131.253.38": 1, "123.125.125.181": 1, "123.125.125.182": 1, "40.79.131": 1, "61.135.169.20": 1, "34.155.98": 1, "61.135.165.20": 1, "65.55.107": 1, "131.253.46.221": 1, "131.253.46.224": 1, "191.232.136.216": 1, "34.147.110": 1, "49.7.21": 1, "49.7.20": 1, "180.153.234": 1, "180.153.236": 1, "207.68.146.222": 1, "207.68.146.221": 1, "111.225.148": 1, "111.225.149": 1, "65.55.219": 1, "65.55.218": 1, "65.55.213": 1, "65.55.212": 1, "65.55.211": 1, "65.55.210": 1, "65.55.217": 1, "65.55.216": 1, "65.55.215": 1, "65.55.214": 1, "199.30.17": 1, "199.30.18": 1, "199.30.19": 1, "203.208.60": 1, "123.125.66": 1, "199.30.26": 1, "191.233.204": 1, "40.77.252": 1, "106.38.241": 1, "40.77.250": 1, "40.77.251": 1, "180.149.133": 1, "40.77.254": 1, "40.77.255": 1, "111.221.31": 1, "180.163.220": 1, "13.66.144": 1, "116.179.32": 1, "66.249.69": 1, "124.166.232": 1, "116.179.37": 1, "106.120.173": 1, "66.249.66": 1, "66.249.64": 1, "66.249.65": 1, "65.55.146": 1, "111.202.101": 1, "123.125.125.151": 1, "111.202.100": 1, "61.135.189": 1, "60.8.151": 1, "42.236.16": 1, "51.105.67": 1, "64.68.88": 1, "42.236.15": 1, "42.236.14": 1, "207.68.155": 1, "65.52.110": 1, "42.156.255": 1, "42.156.254": 1, "61.135.186": 1, "40.77.177": 1, "40.77.176": 1, "40.77.175": 1, "40.77.174": 1, "40.77.173": 1, "40.77.172": 1, "40.77.171": 1, "40.77.170": 1, "40.77.179": 1, "40.77.178": 1, "40.77.216": 1, "40.77.217": 1, "40.77.214": 1, "40.77.215": 1, "40.77.212": 1, "40.77.213": 1, "34.126.178": 1, "40.77.211": 1, "40.77.218": 1, "40.77.219": 1, "34.176.130": 1, "61.49.160.21": 1, "61.49.160.20": 1, "42.236.50": 1, "194.32.107.227": 1, "194.32.107.226": 1, "154.53.40.69": 1, "154.53.40.63": 1, "42.236.17": 1, "157.55.21": 1, "157.55.22": 1, "157.55.23": 1, "42.236.13": 1, "42.236.12": 1, "42.236.10": 1, "34.118.66": 1, "34.80.50": 1, "65.55.25": 1, "104.44.253": 1, "207.68.185.56": 1, "123.126.68": 1, "131.253.47.190": 1, "34.89.198": 1, "207.46.199": 1, "131.253.25": 1, "131.253.24": 1, "131.253.27": 1, "131.253.26": 1, "157.55.2": 1, "157.55.7": 1, "42.156.138": 1, "42.156.139": 1, "52.167.144": 1, "42.156.137": 1, "40.73.148": 1, "157.55.103": 1, "58.250.125": 1, "157.55.106": 1, "157.55.107": 1, "207.46.12.79": 1, "207.46.12.78": 1, "207.46.12.75": 1, "207.46.12.74": 1, "207.46.12.77": 1, "207.46.12.76": 1, "207.46.12.73": 1, "207.46.12.72": 1, "154.53.40.3": 1, "154.53.40.2": 1, "20.79.107": 1, "65.55.208": 1, "65.55.209": 1, "34.96.162": 1, "106.120.188.72": 1, "106.120.188.73": 1, "106.120.188.70": 1, "106.120.188.71": 1, "106.120.188.76": 1, "106.120.188.74": 1, "106.120.188.75": 1, "61.135.165.52": 1, "123.125.71": 1, "123.125.109": 1, "220.181.32": 1, "111.202.103": 1, "220.181.124": 1, "220.181.125": 1, "104.47.224": 1, "199.30.29": 1, "13.71.172": 1, "199.30.23": 1, "199.30.22": 1, "199.30.21": 1, "199.30.20": 1, "199.30.27": 1, "61.49.160.19": 1, "199.30.25": 1, "199.30.24": 1, "34.101.50": 1, "207.68.176.163": 1, "207.68.176.164": 1, "157.55.10": 1, "157.55.13": 1, "157.55.12": 1, "123.125.186.10": 1, "34.22.85.0": 1, "34.22.85.1": 1, "34.22.85.2": 1, "34.22.85.3": 1, "34.22.85.4": 1, "34.22.85.5": 1, "34.22.85.6": 1, "34.22.85.7": 1, "34.151.74": 1, "65.55.54": 1, "123.126.50": 1, "42.236.53": 1, "42.236.52": 1, "42.236.51": 1, "131.253.47.148": 1, "42.236.55": 1, "42.236.54": 1, "131.253.47.147": 1, "199.188.107.110": 1, "64.68.92": 1, "64.68.91": 1, "64.68.90": 1, "61.135.158.72": 1, "66.249.68": 1, "109.238.6.19": 1, "42.156.136": 1}

    with open("/usr/local/openresty/nginx/conf/vhost/openresty.json","w") as fp:
        fp.write(json.dumps(openresty))

EOF

/opt/venv/bin/python /tmp/_db.py

}

update_file() {
cd /opt/$dir_name/
for i in `find ./ | grep -vE "conf/config.py|/nginx/conf/captcha/|/nginx/conf/rotate/|conf/filebeat.yml|^./agent/conf$|^./$|^./agent$"`;do
    \cp -aT $i /opt/cdnfly/$i
done

}


# 定义版本
version_name="v5.5.0"
version_num="50500"
dir_name="cdnfly-agent-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

###########
echo "执行升级命令..."
upgrade_cmd
echo "执行升级命令完成"
###########

echo "更新文件..."
update_file
echo "更新文件完成."

echo "开始重启agent..."

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/agent/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/agent/conf/config.py
rm -f /opt/cdnfly/agent/conf/config.pyc
echo "修改完成"

rm -f /opt/cdnfly/agent/conf/config.pyc
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task
#supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart filebeat

# 重载nginx
ps aux  | grep [/]usr/local/openresty/nginx/sbin/nginx | awk '{print $2}' | xargs kill -HUP || true

# 重启nginx
#force_restart

echo "重启完成"

echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"



