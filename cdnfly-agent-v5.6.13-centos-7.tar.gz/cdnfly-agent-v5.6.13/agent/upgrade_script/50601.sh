#!/bin/bash

set -o errexit

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

start_on_boot(){
    local cmd="$1"
    if [[ -f "/etc/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.local
        if [[ `grep "${cmd}" /etc/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.local
        fi 
        chmod +x /etc/rc.local
    fi


    if [[ -f "/etc/rc.d/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.d/rc.local
        if [[ `grep "${cmd}" /etc/rc.d/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.d/rc.local
        fi 
        chmod +x /etc/rc.d/rc.local 
    fi 
}


#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}

force_restart() {
    now_time=`date +%s`
    echo $now_time > /tmp/monitor_restart.time
    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf stop task
    ok=`/usr/local/openresty/nginx/sbin/nginx -t 2>&1 | grep "syntax is ok" || true`
    if [[ $ok == "" ]];then
        echo "nginx config error"
        exit 1
    fi
        
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
    sleep 2
    rm -f /var/run/nginx.sock
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx
}

upgrade_cmd() {
# 清空日志
log_dir=$(grep access_log /usr/local/openresty/nginx/conf/nginx.conf | grep "\baccess\b" | awk '{print $2}' | sed 's/access.log//g')
if [[ -f $log_dir ]];then
    cd $log_dir
    rm -f access.log-*
    rm -f error.log-*
    cat /dev/null > access.log
    cat /dev/null > error.log
fi

# 备份openresty
rm -rf /usr/local/openresty-50503-bak
\cp -a /usr/local/openresty /usr/local/openresty-50503-bak

# 备份agent
if [[ ! -d /opt/cdnfly-50503-bak ]];then
    \cp -a /opt/cdnfly/ /opt/cdnfly-50503-bak
fi

# hosts
sed -i '/^127\.0\.0\.1\s\+localhost\>/!s/^127\.0\.0\.1\s\+.*$//g' /etc/hosts

mkdir -p /usr/local/openresty/nginx/conf/stream//
echo "{}" > /usr/local/openresty/nginx/conf/stream/foo.json

cd /usr/local/openresty/nginx/conf/stream
if [[ ! -e openresty.json  ]];then
    ln -s ../vhost/openresty.json 
fi

# site配置
master_ip=`grep MASTER_IP /opt/cdnfly/agent/conf/config.py | grep -oP "(\d+.){3}\d+"`
master_host=`grep MASTER_HOST /opt//cdnfly/agent//conf/config.py | grep -oE '"(.*)"'  | sed 's/"//g'`
node_id=`grep NODE_ID /opt/cdnfly/agent/conf/config.py | grep -oE '[0-9]+'`
es_pwd=`grep ES_PWD /opt//cdnfly/agent//conf/config.py | grep -oE '"(.*)"'  | sed 's/"//g'`

host=$master_ip
if [[ $master_host != "" ]];then
    host=$master_host
fi

## 下载agent/{node_id}/listen_80.conf 到conf目录
cd /usr/local/openresty/nginx/conf/
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/listen_80.conf" -O listen_80.conf
sed -i "s/MASTER_IP/$master_ip/" listen_80.conf


## 下载agent/{node_id}/listen_other.conf 到conf目录
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/listen_other.conf" -O listen_other.conf
sed -i "s/MASTER_IP/$master_ip/" listen_other.conf

## 下载agent/{node_id}/nginx.conf 到conf目录
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/nginx.conf" -O nginx.conf

## 下载agent/{node_id}/error_page.json 到vhost目录
cd /usr/local/openresty/nginx/conf/vhost/
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/error_page.json" -O error_page.json


## 下载agent/{node_id}/resolver.txt 到/tmp/目录，并设置为openresty.json的resolver key
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/resolver.txt" -O /tmp/resolver.txt


## 下载agent/{node_id}/site-upstream.json 到vhost/upstream.json
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/site-upstream.json" -O upstream.json


## 下载agent/{node_id}/site.tar到vhost目录，并解压
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/site.tar" -O site.tar
tar xf site.tar

# stream配置
cd /usr/local/openresty/nginx/conf/
## 下载agent/{node_id}/stream_listen.conf 到conf目录
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/stream_listen.conf" -O stream_listen.conf 
if [[ `grep listen stream_listen.conf` == "" ]];then
    echo > stream_listen.conf
fi

## 下载agent/{node_id}/stream.tar到stream目录，并解压
if [[ -d /usr/local/openresty/nginx/conf/stream ]];then
    cd /usr/local/openresty/nginx/conf/stream
    wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/stream.tar" -O stream.tar
    tar xf stream.tar
fi

## 下载agent/{node_id}/stream-upstream.json 到stream/upstream.json
cd /usr/local/openresty/nginx/conf/stream
wget --header="Host: $host" --header="es-pwd: $es_pwd" --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "http://$master_ip:88/agent/$node_id/stream-upstream.json" -O upstream.json


cat > /tmp/_db.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
sys.path.append("/opt/cdnfly/agent/")
from conf.config import ES_PWD
import json
reload(sys) 
import os
sys.setdefaultencoding('utf8')
import re
import subprocess

VHOST_DIR = "/usr/local/openresty/nginx/conf/vhost/"
STREAM_VHOST_DIR = "/usr/local/openresty/nginx/conf/stream/"

def gen_server_name_json():
    # 生成server_name.json  health_check.json default_server.json

    # 根据vhost/数字.json
    upstreams = {}
    health_checks = []
    server_name_port = {}
    default_server = {}
    for p in os.listdir(VHOST_DIR):
        if not p.endswith(".json"):
            continue

        # site_id
        site_id = p.split(".")[0]
        if not site_id.isdigit():
            continue

        with open(VHOST_DIR+p) as fp:
            data = json.loads(fp.read())

        listen_ports = []
        if data['http_listen']:
            listen_ports += data['http_listen']['ports']
        
        if data['https_listen']:
            listen_ports += data['https_listen']['ports']

        for d in data['domain'].split():
            for p in listen_ports:
                server_name_port[d+":"+p] = site_id

        # health_check_list
        health_check_list = data['health_check_list']
        if health_check_list:
            health_checks += health_check_list

        # default_server
        if data['is_default_server']:
            for p in listen_ports:
                default_server[str(p)] = str(site_id)

        # upstream
        if "upstream" in data:
            upstreams[site_id] = data['upstream']

    with open(VHOST_DIR + "/server_name.json","w") as fp:
        fp.write(json.dumps(server_name_port))

    with open(VHOST_DIR + "/health_check.json","w") as fp:
        fp.write(json.dumps(health_checks))

    with open(VHOST_DIR + "/default_server.json","w") as fp:
        fp.write(json.dumps(default_server))
      
    with open(VHOST_DIR + "/upstream.json","w") as fp:
        fp.write(json.dumps(upstreams))

def gen_port_map_json():
    # 生成port_map.json
    # 根据stream/数字.json
    port_map = {}
    upstreams = {}
    for p in os.listdir(STREAM_VHOST_DIR):
        if not p.endswith(".json"):
            continue

        # stream_id
        stream_id = p.split(".")[0]
        if not stream_id.isdigit():
            continue

        with open(STREAM_VHOST_DIR+p) as fp:
            data = json.loads(fp.read())

        listen = data['listen']
        for l in listen:
            port = l['port']
            protocol = l['protocol']
            port_map[protocol+":"+port] = stream_id

        if "upstream" in data:
            upstreams[stream_id] =  data['upstream']

    with open(STREAM_VHOST_DIR + "/port_map.json","w") as fp:
        fp.write(json.dumps(port_map))

    with open(STREAM_VHOST_DIR + "/upstream.json","w") as fp:
        fp.write(json.dumps(upstreams))

def get_memory_info():
    meminfo = {}
    with open('/proc/meminfo') as f:
        for line in f:
            parts = line.split()
            if len(parts) > 1:
                key = parts[0].strip(':')
                value = parts[1]
                meminfo[key] = int(value)
    return meminfo

# 根据 vhost/数字.json 生成 default_server.json health_check.json server_name.json
gen_server_name_json()

# 根据 stream/数字.json生成  port_map.json
if os.path.exists(STREAM_VHOST_DIR):
    gen_port_map_json()

# 设置为openresty.json的resolver key
if os.path.exists("/usr/local/openresty/nginx/conf/vhost/openresty.json"):
    with open("/usr/local/openresty/nginx/conf/vhost/openresty.json") as fp:
        data = fp.read()

    with open("/tmp/resolver.txt") as fp:
        resolver = fp.read()

    openresty = json.loads(data)
    openresty['resolver'] = resolver

    with open("/usr/local/openresty/nginx/conf/vhost/openresty.json","w") as fp:
        fp.write(json.dumps(openresty))


# 替换nginx的cache zone size
with open("/usr/local/openresty/nginx/conf/nginx.conf") as fp:
    nginx_config_data = fp.read()

new_zone_size = str(int(get_memory_info()['MemTotal'] / 1024 / 2)) + "M"
nginx_config_data = re.sub(r'(keys_zone=cache:)\d+M', r'\g<1>' + new_zone_size, nginx_config_data)
with open("/usr/local/openresty/nginx/conf/nginx.conf", "w") as fp:
    fp.write(nginx_config_data)

EOF

/opt/venv/bin/python /tmp/_db.py


# 升级openresty
SYS_VER=`get_sys_ver`
cd /usr/local
download "https://dl2.cdnfly.cn/cdnfly/openresty-$SYS_VER-20240104.tar.gz" "https://us.centos.bz/cdnfly/openresty-$SYS_VER-20240104.tar.gz" "openresty-$SYS_VER.tar.gz"

now_time=`date +%s`
echo $now_time > /tmp/monitor_restart.time
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf stop task
ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
sleep 2
ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
sleep 2

if [[ ! -d "/usr/local/openresty-2024-02-20" ]];then
    mv openresty openresty-2024-02-20
fi

tar xf openresty-$SYS_VER.tar.gz || true

# 恢复配置文件
\cp -a /usr/local/openresty-2024-02-20/nginx/conf /usr/local/openresty/nginx/

}

update_file() {
cd /opt/$dir_name/
for i in `find ./ | grep -vE "conf/config.py|/nginx/conf/captcha/|/nginx/conf/rotate/|conf/filebeat.yml|^./agent/conf$|^./$|^./agent$"`;do
    \cp -aT $i /opt/cdnfly/$i
done

}


# 定义版本
version_name="v5.6.1"
version_num="50601"
dir_name="cdnfly-agent-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

###########
echo "执行升级命令..."
upgrade_cmd
echo "执行升级命令完成"
###########

echo "更新文件..."
update_file
echo "更新文件完成."

echo "开始重启agent..."

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/agent/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/agent/conf/config.py
rm -f /opt/cdnfly/agent/conf/config.pyc
echo "修改完成"

rm -f /opt/cdnfly/agent/conf/config.pyc
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task

# 重载nginx
# ps aux  | grep [/]usr/local/openresty/nginx/sbin/nginx | awk '{print $2}' | xargs kill -HUP || true

# 启动
rm -f /var/run/nginx.sock
ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx

# 重启nginx
#force_restart

# echo "重启完成"

echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
rm -f /usr/local/openresty/nginx/conf/vhost/*.conf /usr/local/openresty/nginx/conf/vhost/*.html  /usr/local/openresty/nginx/conf/vhost/site.tar /usr/local/openresty/nginx/conf/stream/*.conf /usr/local/openresty/nginx/conf/stream/stream.tar
rm -rf /usr/local/openresty/nginx/conf/vhost/error-page
echo "清理完成"

# 测试nginx语法
ok=`/usr/local/openresty/nginx/sbin/nginx -t 2>&1 | grep "syntax is ok" || true`
if [[ $ok == "" ]];then
    echo "升级失败, nginx配置文件出错，开始恢复上一个版本"
    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf stop all

    # 恢复agent
    rm -rf /opt/cdnfly/
    \cp -a /opt/cdnfly-50503-bak /opt/cdnfly/ 

    # 恢复openresty
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
    sleep 2
    rm -f /var/run/nginx.sock
    rm -rf /usr/local/openresty/
    \cp -a  /usr/local/openresty-50503-bak /usr/local/openresty
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx || true

    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf start all
    echo "恢复完成，请联系客服，并提供此日志！"
    exit 1
fi

rm -rf /var/lib/filebeat/registry/* && supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart filebeat

echo "完成$version_name版本升级"



