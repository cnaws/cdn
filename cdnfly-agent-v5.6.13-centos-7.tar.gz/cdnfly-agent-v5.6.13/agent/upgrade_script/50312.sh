#!/bin/bash

set -o errexit

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

start_on_boot(){
    local cmd="$1"
    if [[ -f "/etc/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.local
        if [[ `grep "${cmd}" /etc/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.local
        fi 
        chmod +x /etc/rc.local
    fi


    if [[ -f "/etc/rc.d/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.d/rc.local
        if [[ `grep "${cmd}" /etc/rc.d/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.d/rc.local
        fi 
        chmod +x /etc/rc.d/rc.local 
    fi 
}


#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}
get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)-.*',"\g<1>",sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
print sys_ver
EOF
echo `python /tmp/sys_ver.py`
}

force_restart() {
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
    sleep 2
    rm -f /var/run/nginx.sock
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx
}

upgrade_cmd() {
cat > /tmp/_upgrade.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
import os

sys.path.append("/opt/cdnfly/agent/")
from util import set_dict

reload(sys) 
sys.setdefaultencoding('utf8')

def get_uuid():
    product_uuid_path = "/sys/class/dmi/id/product_uuid"
    if os.path.exists(product_uuid_path):
        with open(product_uuid_path) as fp:
            return fp.read().strip()[0:36]

    with open("/etc/hostname") as fp:
        return fp.read().strip()[0:36]

uuid = get_uuid()
ok, err = set_dict([{"key":"uuid", "value": uuid,"exp":0}])
if not ok:
    print err
    sys.exit(1)

EOF

/opt/venv/bin/python /tmp/_upgrade.py

# 400错误页
chattr -i /usr/local/openresty/nginx/conf/vhost/
cat > /usr/local/openresty/nginx/conf/vhost/400.html <<'EOF'
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en-US"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en-US"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en-US"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en-US"> <!--<![endif]-->
<head>
<title>请求无效</title>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta name="robots" content="noindex, nofollow" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
*, body, html {
    margin: 0;
    padding: 0;
}

body, html {
    --text-opacity: 1;
    color: #404040;
    color: rgba(64,64,64,var(--text-opacity));
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-family: system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;
    font-size: 16px;
}
* {
    box-sizing: border-box;
}
html[Attributes Style] {
    -webkit-locale: "en-US";
}
.p-0 {
    padding: 0;
}


.w-240 {
    width: 60rem;
}

.antialiased {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.pt-10 {
    padding-top: 2.5rem;
}
.mb-15 {
    margin-bottom: 3.75rem;
}
.mx-auto {
    margin-left: auto;
    margin-right: auto;
}

.text-black-dark {
    --text-opacity: 1;
    color: #404040;
    color: rgba(64,64,64,var(--text-opacity));
}

.mr-2 {
    margin-right: .5rem;
}
.leading-tight {
    line-height: 1.25;
}
.text-60 {
    font-size: 60px;
}
.font-light {
    font-weight: 300;
}
.inline-block {
    display: inline-block;
}

.text-15 {
    font-size: 15px;
}
.font-mono {
    font-family: monaco,courier,monospace;
}
.text-gray-600 {
    --text-opacity: 1;
    color: #999;
    color: rgba(153,153,153,var(--text-opacity));
}
.leading-1\.3 {
    line-height: 1.3;
}
.text-3xl {
    font-size: 1.875rem;
}

.mb-8 {
    margin-bottom: 2rem;
}

.w-1\/2 {
    width: 50%;
}

.mt-6 {
    margin-top: 1.5rem;
}

.mb-4 {
    margin-bottom: 1rem;
}


.font-normal {
    font-weight: 400;
}

#what-happened-section p {
    font-size: 15px;
    line-height: 1.5;
}

</style>

</head>
<body>
  <div id="cf-wrapper">
    <div id="cf-error-details" class="p-0">
      <header class="mx-auto pt-10 lg:pt-6 lg:px-8 w-240 lg:w-full mb-15 antialiased">
         <h1 class="inline-block md:block mr-2 md:mb-2 font-light text-60 md:text-3xl text-black-dark leading-tight">
           <span data-translate="error">Error</span>
           <span>403</span>
         </h1>
         <span class="inline-block md:block heading-ray-id font-mono text-15 lg:text-sm lg:leading-relaxed">您的IP: {client_ip} &bull;</span>
         <span class="inline-block md:block heading-ray-id font-mono text-15 lg:text-sm lg:leading-relaxed">节点IP: {node_ip}</span>
        <h2 class="text-gray-600 leading-1.3 text-3xl lg:text-2xl font-light">当前请求无效</h2>
      </header>

      <section class="w-240 lg:w-full mx-auto mb-8 lg:px-8">
          <div id="what-happened-section" class="w-1/2 md:w-full">
            <h2 class="text-3xl leading-tight font-normal mb-4 text-black-dark antialiased" data-translate="what_happened">什么问题?</h2>
            <p>您的请求无效</p>
            
          </div>

          
          <div id="resolution-copy-section" class="w-1/2 mt-6 text-15 leading-normal">
            <h2 class="text-3xl leading-tight font-normal mb-4 text-black-dark antialiased" data-translate="what_can_i_do">如何解决?</h2>
            <p>可以联系网站管理员咨询原因</p>
          </div>
          
      </section>

      <div class="cf-error-footer cf-wrapper w-240 lg:w-full py-10 sm:py-4 sm:px-8 mx-auto text-center sm:text-left border-solid border-0 border-t border-gray-300">

</div><!-- /.error-footer -->


    </div><!-- /#cf-error-details -->
  </div><!-- /#cf-wrapper -->


</body>
</html>
EOF
chattr +i /usr/local/openresty/nginx/conf/vhost/

if [[ `grep "error_page 400" /usr/local/openresty/nginx/conf/listen_80.conf` == "" ]];then
    chattr -i /usr/local/openresty/nginx/conf/listen_80.conf /usr/local/openresty/nginx/conf/
    sed -i '/error_page 530/aerror_page 400  /400.html;' /usr/local/openresty/nginx/conf/listen_80.conf
    sed -i 's#location /host_not_found.html#location ~ "^(/host_not_found.html|/400.html)"#' /usr/local/openresty/nginx/conf/listen_80.conf
    chattr +i /usr/local/openresty/nginx/conf/listen_80.conf /usr/local/openresty/nginx/conf/
fi

if [[ `grep "error_page 400" /usr/local/openresty/nginx/conf/listen_other.conf` == "" ]];then
    chattr -i /usr/local/openresty/nginx/conf/listen_other.conf /usr/local/openresty/nginx/conf/
    sed -i '/error_page 530/aerror_page 400  /400.html;' /usr/local/openresty/nginx/conf/listen_other.conf
    sed -i 's#location /host_not_found.html#location ~ "^(/host_not_found.html|/400.html)"#' /usr/local/openresty/nginx/conf/listen_other.conf
    chattr +i /usr/local/openresty/nginx/conf/listen_other.conf /usr/local/openresty/nginx/conf/
fi

# 内核优化
if [[ `grep net.ipv4.tcp_max_syn_backlog /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_max_syn_backlog=65536" >> /etc/sysctl.conf
fi


if [[ `grep net.core.somaxconn /etc/sysctl.conf` == "" ]]; then
  echo "net.core.somaxconn=65535" >> /etc/sysctl.conf
fi

if [[ `grep net.core.netdev_max_backlog /etc/sysctl.conf` == "" ]]; then
  echo "net.core.netdev_max_backlog=16384" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_max_tw_buckets /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_max_tw_buckets=55000" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_fin_timeout /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_fin_timeout=30" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_keepalive_time /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_keepalive_time=600" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_synack_retries /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_synack_retries=3" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_syn_retries /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_syn_retries=3" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_max_orphans /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_max_orphans=65536" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.ip_local_port_range /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.ip_local_port_range=1024 65535" >> /etc/sysctl.conf
fi


if [[ `grep net.ipv4.tcp_window_scaling /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_window_scaling=1" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_mem /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_mem=4096 87380 16777216" >> /etc/sysctl.conf
fi

if [[ `grep net.ipv4.tcp_moderate_rcvbuf /etc/sysctl.conf` == "" ]]; then
  echo "net.ipv4.tcp_moderate_rcvbuf=1" >> /etc/sysctl.conf
fi

if [[ `grep net.core.default_qdisc /etc/sysctl.conf` == "" ]]; then
  echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
fi

sysctl -p || true

# 日志格式增加site_id
if [[ `grep site_id /usr/local/openresty/nginx/conf/nginx.conf` == ""  ]];then
    chattr -i /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/
    sed -i '0,/upid/{s/\\t$upid/\\t$upid\\t$site_id/}' /usr/local/openresty/nginx/conf/nginx.conf
    chattr +i /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/
fi

# nginx server里加site_id
if [[ `grep 'set $site_id 0;' /usr/local/openresty/nginx/conf/nginx.conf` == ""  ]];then
    chattr -i /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/
    sed -i '/access_log off/iset $site_id 0;' /usr/local/openresty/nginx/conf/nginx.conf
    chattr +i /usr/local/openresty/nginx/conf/nginx.conf /usr/local/openresty/nginx/conf/
fi

# 监控点白名单
ipset -! add cdnfly_white 49.7.135.3
ipset -! add cdnfly_white 119.96.229.174
ipset -! add cdnfly_white 36.134.112.244
ipset -! add cdnfly_white 36.133.240.200
ipset -! add cdnfly_white 36.140.82.9
ipset -! add cdnfly_white 125.39.179.198
ipset -! add cdnfly_white 211.90.241.52
ipset -! add cdnfly_white 112.91.140.167

cat >> /opt/global_white_ip_list <<EOF

add cdnfly_white 49.7.135.3 timeout 0
add cdnfly_white 119.96.229.174 timeout 0
add cdnfly_white 36.134.112.244 timeout 0
add cdnfly_white 36.133.240.200 timeout 0
add cdnfly_white 36.140.82.9 timeout 0
add cdnfly_white 125.39.179.198 timeout 0
add cdnfly_white 211.90.241.52 timeout 0
add cdnfly_white 112.91.140.167 timeout 0
EOF

rm -rf /var/lib/filebeat/registry/* && supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart filebeat


}

update_file() {
cd /opt/$dir_name/
for i in `find ./ | grep -vE "conf/config.py|conf/filebeat.yml|^./agent/conf$|^./$|^./agent$"`;do
    \cp -aT $i /opt/cdnfly/$i
done

}


# 定义版本
version_name="v5.3.12"
version_num="50312"
dir_name="cdnfly-agent-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

###########
echo "执行升级命令..."
upgrade_cmd
echo "执行升级命令完成"
###########

echo "更新文件..."
update_file
echo "更新文件完成."

echo "开始重启agent..."

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/agent/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/agent/conf/config.py
echo "修改完成"

supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task
#supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart filebeat
ps aux  | grep [/]usr/local/openresty/nginx/sbin/nginx | awk '{print $2}' | xargs kill -HUP || true
# 重启nginx

#ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
# sleep 2
# ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
# ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx

echo "重启完成"


echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"



