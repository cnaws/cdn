#!/bin/bash

# 两天更新一次
expire=172800
time_pass=$expire

if [[ -f /opt/update_ip.time ]];then
  file_mtime=$(stat -c %Y /opt/update_ip.time)  # 获取文件的最后修改时间（以Epoch秒为单位）
  current_time=$(date +%s)                 # 获取当前时间（以Epoch秒为单位）

  time_pass=$((current_time - file_mtime))
fi

if [[ $time_pass -lt $expire ]];then
  echo "仅过去$time_pass秒, 不够两天,退出"
  exit 0
fi

touch /opt/update_ip.time

mkdir -p /opt/awdb/
cd /tmp
rm -f cjson.so.1.7.12.gz.bin.tar cjson.so.1.7.12.gz.bin
# 从us下载，限时512秒
timeout 512 wget -T 60 -t 3 -c http://ip-us.cdnfly.cn/cdnfly/cjson.so.1.7.12.gz.bin.tar
if tar -tf cjson.so.1.7.12.gz.bin.tar;then
  # 测试成功后，复制到指定位置
  echo "us download success."
  tar xf cjson.so.1.7.12.gz.bin.tar
  \cp cjson.so.1.7.12.gz.bin /opt/awdb/cjson.so.1.7.12.gz.bin
  exit 0
fi

# 从cn下载，不限时
echo "us download failed, start use cn download..."
rm -f cjson.so.1.7.12.gz.bin.tar cjson.so.1.7.12.gz.bin
wget -T 60 -t 3 -c http://ip-cn.cdnfly.cn/cdnfly/cjson.so.1.7.12.gz.bin.tar
if tar -tf cjson.so.1.7.12.gz.bin.tar;then
  # 测试成功后，复制到指定位置
  echo "cn download success."
  tar xf cjson.so.1.7.12.gz.bin.tar
  \cp cjson.so.1.7.12.gz.bin /opt/awdb/cjson.so.1.7.12.gz.bin
  exit 0
else
  echo "cn download failed"
fi