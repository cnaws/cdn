#!/bin/bash

set -o errexit

export PIP_DISABLE_PIP_VERSION_CHECK=1

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

# 安装依赖
install_depend() {
    if check_sys sysRelease ubuntu;then
        SYS_VER=`python2 -c "import platform;import re;sys_ver = platform.platform();sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver);print sys_ver;"`
        if [[ $SYS_VER =~ "Ubuntu-22.04" ]];then
            apt-get -y install perl autoconf automake libtool openssl libcurl4-openssl-dev libpcre3-dev libssl-dev zlib1g-dev g++ python-pip ipset python2-dev libffi-dev rsyslog cpulimit
            touch /etc/rc.local
            chmod +x /etc/rc.local

        else 
            apt-get -y install perl autoconf automake libtool openssl libcurl3-dev libpcre3-dev libssl-dev zlib1g-dev g++ python-pip ipset python-dev libffi-dev rsyslog cpulimit

        fi
    elif check_sys sysRelease debian;then
        SYS_VER=`python2 -c "import platform;import re;sys_ver = platform.platform();sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver);print sys_ver;"`
        if [[ $SYS_VER =~ "debian-11" ]];then
            cd /tmp
            download "https://dl2.cdnfly.cn/cdnfly/get-pip.py" "https://us.centos.bz/cdnfly/get-pip.py" "get-pip.py"
            python2 get-pip.py -i https://pypi.tuna.tsinghua.edu.cn/simple

            apt-get -y install perl autoconf automake libtool openssl libcurl4-openssl-dev libpcre3-dev libssl-dev zlib1g-dev g++  ipset python2-dev libffi-dev rsyslog cpulimit
            touch /etc/rc.local
            chmod +x /etc/rc.local

        fi

    elif check_sys sysRelease centos;then
        yum install -y perl autoconf automake libtool curl-devel pcre-devel openssl openssl-devel zlib-devel gcc-c++   unzip ipset python-devel curl libffi-devel 
        cd /etc/yum.repos.d/
        download "https://dl2.cdnfly.cn/cdnfly/epel.repo" "https://us.centos.bz/cdnfly/epel.repo" "epel.repo"
        
        sed -i 's#https://#http://#g' /etc/yum.repos.d/epel*repo
        yum install -y python-pip cpulimit || true
        if [[ `yum list installed  | grep python2-pip` == "" ]]; then
            sed -i 's#mirrors.aliyun.com#mirrors.ustc.edu.cn#' /etc/yum.repos.d/epel.repo
            yum install -y python-pip cpulimit
        fi
    fi    
}

install_python_module() {
    cd /tmp
    download "https://dl2.cdnfly.cn/cdnfly/pymodule-agent-20230411.tar.gz" "https://us.centos.bz/cdnfly/pymodule-agent-20230411.tar.gz" "pymodule-agent-20230411.tar.gz"
    tar xf pymodule-agent-20230411.tar.gz
    cd pymodule-agent-20230411

    PIP_PATH="/usr/bin/pip2"
    SYS_VER=`python2 -c "import platform;import re;sys_ver = platform.platform();sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver);print sys_ver;"`
    if [[ $SYS_VER =~ "debian-11" ]];then
        PIP_PATH="/usr/local/bin/pip2.7"
    fi


    # 系统环境安装
    ## pip
    $PIP_PATH install pip-20.1.1-py2.py3-none-any.whl
    ## setuptools
    $PIP_PATH install setuptools-30.1.0-py2.py3-none-any.whl
    ## supervisor
    $PIP_PATH install supervisor-4.2.0-py2.py3-none-any.whl
    ## virtualenv
    $PIP_PATH install configparser-4.0.2-py2.py3-none-any.whl
    $PIP_PATH install scandir-1.10.0.tar.gz
    $PIP_PATH install typing-3.7.4.1-py2-none-any.whl
    $PIP_PATH install contextlib2-0.6.0.post1-py2.py3-none-any.whl
    $PIP_PATH install zipp-1.2.0-py2.py3-none-any.whl
    $PIP_PATH install six-1.15.0-py2.py3-none-any.whl
    $PIP_PATH install singledispatch-3.4.0.3-py2.py3-none-any.whl
    $PIP_PATH install distlib-0.3.0.zip
    $PIP_PATH install pathlib2-2.3.5-py2.py3-none-any.whl
    $PIP_PATH install importlib_metadata-1.6.1-py2.py3-none-any.whl
    $PIP_PATH install appdirs-1.4.4-py2.py3-none-any.whl
    $PIP_PATH install filelock-3.0.12.tar.gz
    $PIP_PATH install importlib_resources-2.0.1-py2.py3-none-any.whl
    $PIP_PATH install virtualenv-20.0.25-py2.py3-none-any.whl

    # 创建虚拟环境
    cd /opt
    /usr/bin/python2 -m virtualenv -vv --extra-search-dir /tmp/pymodule-agent-20230411 --no-download --no-periodic-update venv
    ## 激活环境
    source /opt/venv/bin/activate

    # 虚拟环境安装
    cd /tmp/pymodule-agent-20230411

    ## Flask
    pip install click-7.1.2-py2.py3-none-any.whl
    pip install itsdangerous-1.1.0-py2.py3-none-any.whl
    pip install Werkzeug-1.0.1-py2.py3-none-any.whl 
    pip install MarkupSafe-1.1.1-cp27-cp27mu-manylinux1_x86_64.whl
    pip install Jinja2-2.11.2-py2.py3-none-any.whl 
    pip install Flask-1.1.1-py2.py3-none-any.whl
    ## psutil
    #pip install psutil-5.7.0.tar.gz
    pip install psutil-5.8.0-cp27-cp27mu-manylinux2010_x86_64.whl
    ## bcrypt
    pip install pycparser-2.20-py2.py3-none-any.whl 
    pip install cffi-1.14.0-cp27-cp27mu-manylinux1_x86_64.whl
    pip install six-1.15.0-py2.py3-none-any.whl 
    pip install bcrypt-3.1.7-cp27-cp27mu-manylinux1_x86_64.whl
    ## requests
    pip install certifi-2020.4.5.2-py2.py3-none-any.whl 
    pip install idna-2.9-py2.py3-none-any.whl
    pip install chardet-3.0.4-py2.py3-none-any.whl 
    pip install urllib3-1.25.9-py2.py3-none-any.whl
    pip install requests-2.24.0-py2.py3-none-any.whl
    ## requests_unixsocket
    pip install requests_unixsocket-0.2.0-py2.py3-none-any.whl
    ## pyOpenSSL
    pip install ipaddress-1.0.23-py2.py3-none-any.whl 
    pip install enum34-1.1.10-py2-none-any.whl 
    pip install cryptography-2.9.2-cp27-cp27mu-manylinux2010_x86_64.whl
    pip install pyOpenSSL-19.1.0-py2.py3-none-any.whl
    ## python_dateutil
    pip install python_dateutil-2.8.1-py2.py3-none-any.whl 
    ## APScheduler
    pip install funcsigs-1.0.2-py2.py3-none-any.whl 
    pip install futures-3.3.0-py2-none-any.whl 
    pip install pytz-2020.1-py2.py3-none-any.whl 
    pip install tzlocal-2.1-py2.py3-none-any.whl 
    pip install APScheduler-3.6.3-py2.py3-none-any.whl 
    ## gunicorn
    pip install gunicorn-19.10.0-py2.py3-none-any.whl
    ## gevent
    pip install zope.event-4.4-py2.py3-none-any.whl 
    pip install greenlet-2.0.1-cp27-cp27mu-manylinux2010_x86_64.whl 
    pip install zope.interface-5.1.0-cp27-cp27mu-manylinux2010_x86_64.whl 
    pip install gevent-22.10.2-cp27-cp27mu-manylinux2010_x86_64.whl 
    ## requests_toolbelt
    pip install requests_toolbelt-0.9.1-py2.py3-none-any.whl 
    ## python_daemon
    pip install docutils-0.16-py2.py3-none-any.whl
    pip install lockfile-0.12.2-py2.py3-none-any.whl
    pip install python_daemon-2.2.4-py2.py3-none-any.whl

    ## redis
    pip install redis-3.5.3-py2.py3-none-any.whl

    ## Flask-Compress
    pip install Brotli-1.0.9-cp27-cp27mu-manylinux1_x86_64.whl
    pip install Flask-Compress-1.8.0.tar.gz

    # python_engineio
    pip install python_engineio-3.11.2-py2.py3-none-any.whl

    # python_socketio
    pip install python_socketio-4.4.0-py2.py3-none-any.whl

    # gevent-websocket
    pip install gevent-websocket-0.10.1.tar.gz

    # websocket_client
    pip install websocket_client-0.59.0-py2.py3-none-any.whl

    # Pillow
    pip install Pillow-6.2.2-cp27-cp27mu-manylinux1_x86_64.whl
    deactivate
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}


install_openresty() {
    # openresty
    cd /usr/local
    rm -rf openresty
    download "https://dl2.cdnfly.cn/cdnfly/openresty-$(get_sys_ver)-20240322.tar.gz" "https://us.centos.bz/cdnfly/openresty-$(get_sys_ver)-20240322.tar.gz" "openresty-$(get_sys_ver).tar.gz"
    tar xf openresty-$(get_sys_ver).tar.gz
    mkdir -p /data/nginx/cache
    mkdir -p /var/log/cdnfly/
    start_on_boot "ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx"

    # 安装libaiwendb
    mkdir -p /usr/local/lib
    cd /usr/local/lib
    rm -f libaiwendb.so*
    cp /opt/cdnfly/nginx/lib/libaiwendb.so.0.0.7 .
    mkdir -p /lib/x86_64-linux-gnu/
    \cp /opt/cdnfly/nginx/lib/libcrypto.so.1.0.0 /lib/x86_64-linux-gnu/
    ln -s libaiwendb.so.0.0.7 libaiwendb.so.0
    ln -s libaiwendb.so.0.0.7 libaiwendb.so
    echo -e "/usr/local/lib/\n/lib/x86_64-linux-gnu/" > /etc/ld.so.conf.d/local.conf
    ldconfig

    mkdir -p /usr/local/openresty/nginx/conf/vhost/
    cd /usr/local/openresty/nginx/conf/vhost/
    touch /usr/local/openresty/nginx/conf/stream_listen.conf
    echo "{}" > /usr/local/openresty/nginx/conf/vhost/server_name.json
    echo "{}" > /usr/local/openresty/nginx/conf/vhost/default_server.json
    mkdir -p /usr/local/openresty/nginx/conf/stream//
    echo "{}" > /usr/local/openresty/nginx/conf/stream/foo.json
    echo "{}" > /usr/local/openresty/nginx/conf/vhost/user_package_config.json 
    echo "{}" > /usr/local/openresty/nginx/conf/vhost/health_check.json

    # 下载rotate.tar.gz到/opt/cdnfly/nginx/conf，并解压
    cd /opt/cdnfly/nginx/conf
    download "https://dl2.cdnfly.cn/cdnfly/rotate.tar.gz" "https://us.centos.bz/cdnfly/rotate.tar.gz" "rotate.tar.gz"
    rm -rf rotate rotate-origin
    tar xf rotate.tar.gz
    cp -a rotate rotate-origin
    rm -f rotate.tar.gz

    cp -a captcha captcha-origin

    # 下载ip库
    mkdir -p /opt/awdb/
    cd /opt/awdb/
    rm -f *
    download "http://ip-cn.cdnfly.cn/cdnfly/cjson.so.1.7.12.gz.bin.tar" "http://ip-us.cdnfly.cn/cdnfly/cjson.so.1.7.12.gz.bin.tar" "cjson.so.1.7.12.gz.bin.tar"
    tar xf cjson.so.1.7.12.gz.bin.tar

}

install_redis() {
    if [[ ! -d "/usr/local/redis" ]]; then
        cd /usr/local
        download "https://dl2.cdnfly.cn/cdnfly/redis-$(get_sys_ver)-20200714.tar.gz" "https://us.centos.bz/cdnfly/redis-$(get_sys_ver)-20200714.tar.gz" "redis-$(get_sys_ver).tar.gz"
        tar xf redis-$(get_sys_ver).tar.gz
    fi
}

install_filebeat() {
    if [[ ! -d /etc/filebeat/ ]]; then
        if check_sys sysRelease ubuntu || check_sys sysRelease debian;then
            cd /tmp
            download "https://dl2.cdnfly.cn/cdnfly/filebeat-7.10.0-amd64.deb" "https://us.centos.bz/cdnfly/filebeat-7.10.0-amd64.deb" "filebeat-7.10.0-amd64.deb"
            dpkg -i filebeat-7.10.0-amd64.deb

        elif check_sys sysRelease centos;then
            cd /tmp
            download "https://dl2.cdnfly.cn/cdnfly/filebeat-7.10.0-x86_64.rpm" "https://us.centos.bz/cdnfly/filebeat-7.10.0-x86_64.rpm" "filebeat-7.10.0-x86_64.rpm"
            yum install -y filebeat-7.10.0-x86_64.rpm
        fi

        mkdir -p /var/log/cdnfly/

    fi
    
    # 修改配置
    sed -i "s/192.168.0.30/$ES_IP/" /opt/cdnfly/agent/conf/filebeat.yml
    sed -i "s/ES_PWD/$ES_PWD/" /opt/cdnfly/agent/conf/filebeat.yml
    chmod 600 /opt/cdnfly/agent/conf/filebeat.yml
    chown root /opt/cdnfly/agent/conf/filebeat.yml

}

sync_time(){
    echo "start to sync time and add sync command to cronjob..."

    if [[ $ignore_ntp == false ]]; then
      if check_sys sysRelease ubuntu || check_sys sysRelease debian;then
          apt-get -y update
          apt-get -y install ntpdate wget
      elif check_sys sysRelease centos; then
          yum -y install ntpdate wget
          

      fi
      /usr/sbin/ntpdate -u pool.ntp.org || true
      crontab -l | grep -q "/usr/sbin/ntpdate -u pool.ntp.org" || (crontab -l ; echo '*/10 * * * * /usr/sbin/ntpdate -u pool.ntp.org > /dev/null 2>&1 || (date_str=`curl update.cdnfly.cn/common/datetime` && timedatectl set-ntp false && echo $date_str && timedatectl set-time "$date_str" )') | crontab -
    
    fi

    # 时区
    rm -f /etc/localtime
    ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

    if /sbin/hwclock -w;then
        return
    fi 


}


config() {
    sed -i "s/127.0.0.1/$MASTER_IP/" /opt/cdnfly/agent/conf/config.py
    sed -i "s/192.168.0.30/$ES_IP/" /opt/cdnfly/agent/conf/config.py
    sed -i "s/ES_PWD =.*/ES_PWD = \"$ES_PWD\"/" /opt/cdnfly/agent/conf/config.py
    sed -i "s/MASTER_HOST =.*/MASTER_HOST = \"$MASTER_HOST\"/" /opt/cdnfly/agent/conf/config.py

    crontab -l | grep -q "/opt/cdnfly/agent/sh/monitor_task.sh" || (crontab -l ; echo '* * * * *  bash /opt/cdnfly/agent/sh/monitor_task.sh') | crontab -

    if [[ `grep "localhost" /etc/hosts | grep 127.0.0.1` == ""  ]];then
      echo "127.0.0.1       localhost" >> /etc/hosts
    fi

    # 更新验证码及旋转图片
    cd /opt/cdnfly/agent/sh
    source /opt/venv/bin/activate
    python2 update_captcha.py
    python2 update_rotate.py
    deactivate

}

start_on_boot(){
    local cmd="$1"
    if [[ -f "/etc/rc.local" ]]; then
        # 检查是否存在#!/bin/sh
        if [[ `grep "#!/bin/sh" /etc/rc.local` == "" ]];then 
            sed -i '1i #!/bin/sh' /etc/rc.local
        fi

        if [[ `grep "#!/bin/sh" /etc/rc.local` == "" ]];then 
            echo '#!/bin/sh' > /etc/rc.local
        fi

        sed -i '/exit 0/d' /etc/rc.local
        if [[ `grep "${cmd}" /etc/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.local
        fi 
        chmod +x /etc/rc.local
    fi


    if [[ -f "/etc/rc.d/rc.local" ]]; then
        # 检查是否存在#!/bin/sh
        if [[ `grep "#!/bin/sh" /etc/rc.d/rc.local` == "" ]];then 
            sed -i '1i #!/bin/sh' /etc/rc.d/rc.local
        fi

        if [[ `grep "#!/bin/sh" /etc/rc.d/rc.local` == "" ]];then 
            echo '#!/bin/sh' > /etc/rc.d/rc.local
        fi            

        sed -i '/exit 0/d' /etc/rc.d/rc.local
        if [[ `grep "${cmd}" /etc/rc.d/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.d/rc.local
        fi 
        chmod +x /etc/rc.d/rc.local 
    fi 
}

install_rsyslog() {
# rsyslog
cat > /etc/rsyslog.d/cdnfly.conf <<'EOF'

    $ModLoad imudp
    $UDPServerRun 514
    $Umask 0000
    :msg,contains,"[cdnfly" /var/log/cdnfly.log
    $Umask 0022
    $EscapeControlCharactersOnReceive off
EOF

service rsyslog restart || true

mkdir -p /var/log/cdnfly/    

}

start() {
    kernel_tune
    start_on_boot "supervisord -c /opt/cdnfly/agent/conf/supervisord.conf"
    if ! supervisord -c /opt/cdnfly/agent/conf/supervisord.conf > /dev/null 2>&1;then
        supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf reload
    fi
    
    rm -rf /opt/cdnfly/master
    chmod +x /opt/cdnfly/agent/sh/*.sh

    # 关闭防火墙
    if check_sys sysRelease centos; then
        systemctl stop firewalld.service || true
        systemctl disable firewalld.service || true
    fi

    # 添加cdnfly ipset
    if ! ipset list cdnfly > /dev/null 2>&1; then
        ipset -N cdnfly iphash maxelem 10000000 timeout 3600
    fi

    if ! ipset list cdnfly_white > /dev/null 2>&1; then
        ipset -N cdnfly_white iphash maxelem 10000000 timeout 0
    fi

    if ! ipset list cdnfly_black > /dev/null 2>&1; then
        ipset -N cdnfly_black iphash maxelem 10000000 timeout 0
    fi

    # 添加iptables
    if [[ $(iptables -t filter -S INPUT 1 | grep -- '-A INPUT -m set --match-set cdnfly_white src -j ACCEPT') == "" ]];then
        iptables -D INPUT -m set --match-set cdnfly src -j DROP || true
        iptables -D INPUT -m set --match-set cdnfly_black src -j DROP || true
        iptables -D INPUT -m set --match-set cdnfly_white src -j ACCEPT || true
        

        iptables -I INPUT -m set --match-set cdnfly src -j DROP || true
        iptables -I INPUT -m set --match-set cdnfly_black src -j DROP || true
        iptables -I INPUT -m set --match-set cdnfly_white src -j ACCEPT || true
    fi

    # 添加cdnfly ipset ipv6
    if ! ipset list cdnfly_v6 > /dev/null 2>&1; then
        ipset create cdnfly_v6 hash:net family inet6 maxelem 10000000 timeout 3600
    fi

    if ! ipset list cdnfly_white_v6 > /dev/null 2>&1; then
        ipset create cdnfly_white_v6 hash:net family inet6 maxelem 10000000 timeout 0
    fi

    if ! ipset list cdnfly_black_v6 > /dev/null 2>&1; then
        ipset create cdnfly_black_v6 hash:net family inet6 maxelem 10000000 timeout 0
    fi

    # 添加iptables v6
    if [[ $(ip6tables -t filter -S INPUT 1 | grep -- '-A INPUT -m set --match-set cdnfly_white_v6 src -j ACCEPT') == "" ]];then
        ip6tables -D INPUT -m set --match-set cdnfly_v6 src -j DROP || true
        ip6tables -D INPUT -m set --match-set cdnfly_black_v6 src -j DROP || true
        ip6tables -D INPUT -m set --match-set cdnfly_white_v6 src -j ACCEPT || true
        

        ip6tables -I INPUT -m set --match-set cdnfly_v6 src -j DROP || true
        ip6tables -I INPUT -m set --match-set cdnfly_black_v6 src -j DROP || true
        ip6tables -I INPUT -m set --match-set cdnfly_white_v6 src -j ACCEPT || true
    fi
        
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx || true
    uuid=`get_uuid`
    echo "安装节点成功！"
    echo "开始往主控发送请求注册节点..."
    cmd="curl -v -m 10 -k --resolve $MASTER_HOST:88:$MASTER_IP  -X POST -H \"Host: $MASTER_HOST\"  http://$MASTER_HOST:88/new-node -H \"es-pwd: $ES_PWD\" -H \"uuid: $uuid\" "
    ret=`eval $cmd || true`
    if [[ "$ret" =~ "success" ]];then
        echo "注册成功，请登录后台，切换到待初始化菜单, 来初始化节点"

    elif [[ "$ret" =~ "node task created" ]];then
        echo "该节点已存在于CDN后台，已自动创建节点同步任务"

    else
        echo "注册失败，请手动执行如下命令来注册"
        echo $cmd
    fi

}

kernel_tune() {
    if [[ `grep net.ipv4.tcp_max_syn_backlog /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_max_syn_backlog=8192" >> /etc/sysctl.conf
    fi


    if [[ `grep net.core.somaxconn /etc/sysctl.conf` == "" ]]; then
        echo "net.core.somaxconn=40000" >> /etc/sysctl.conf
    fi

    if [[ `grep net.core.netdev_max_backlog /etc/sysctl.conf` == "" ]]; then
        echo "net.core.netdev_max_backlog=8096" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_max_tw_buckets /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_max_tw_buckets=5000" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_fin_timeout /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_fin_timeout=60" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_keepalive_time /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_keepalive_time=7200" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_synack_retries /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_synack_retries=2" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_syn_retries /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_syn_retries=6" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.ip_local_port_range /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.ip_local_port_range=32768 60999" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_window_scaling /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_window_scaling=1" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_moderate_rcvbuf /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_moderate_rcvbuf=1" >> /etc/sysctl.conf
    fi

    if [[ `grep net.core.default_qdisc /etc/sysctl.conf` == "" ]]; then
        echo "net.core.default_qdisc=pfifo_fast" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_rmem /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_rmem=4096        87380   6291456" >> /etc/sysctl.conf
    fi

    if [[ `grep net.ipv4.tcp_wmem /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_wmem=4096        16384   4194304" >> /etc/sysctl.conf
    fi

    if [[ `grep net.core.rmem_max /etc/sysctl.conf` == "" ]]; then
        echo "net.core.rmem_max=212992" >> /etc/sysctl.conf
    fi

    if [[ `grep net.core.wmem_max /etc/sysctl.conf` == "" ]]; then
        echo "net.core.wmem_max=212992" >> /etc/sysctl.conf
    fi

    memtotal=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    tcp_mem="22746        30329   45492"
    tcp_max_orphans="8192"

    if [[ $memtotal -ge 63000000 ]];then
        tcp_mem="747072       996097  1494144"
        tcp_max_orphans="262144"

    elif [[ $memtotal -ge 31000000 ]];then
        tcp_mem="372120       496162  744240"
        tcp_max_orphans="131072"

    elif [[ $memtotal -ge 15000000 ]];then
        tcp_mem="184644       246195  369288"
        tcp_max_orphans="65536"

    elif [[ $memtotal -ge 7000000 ]];then
        tcp_mem="90906        121211  181812"
        tcp_max_orphans="32768"

    elif [[ $memtotal -ge 3000000 ]];then
        tcp_mem="44037        58719   88074"
        tcp_max_orphans="16384"

    fi

    # net.ipv4.tcp_mem
    if [[ `grep net.ipv4.tcp_mem /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_mem=$tcp_mem" >> /etc/sysctl.conf
    fi

    # net.ipv4.tcp_max_orphans
    if [[ `grep net.ipv4.tcp_max_orphans /etc/sysctl.conf` == "" ]]; then
        echo "net.ipv4.tcp_max_orphans=$tcp_max_orphans" >> /etc/sysctl.conf
    fi

    sysctl -p || true
}

get_uuid() {
    cd /opt/cdnfly/agent
    /opt/venv/bin/python -c "import util;print util.get_uuid()"
}

need_sys() {
    SYS_VER=`python2 -c "import platform;import re;sys_ver = platform.platform();re.sub(r'.*-with-(.*)','\g<1>',sys_ver);print sys_ver;"`
    if [[ $SYS_VER =~ "Ubuntu-16.04" ]];then
      echo "$sys_ver"
    elif [[ $SYS_VER =~ "Ubuntu-22.04" ]];then
      echo "$sys_ver"      
    elif [[ $SYS_VER =~ "centos-7" ]]; then
      SYS_VER="centos-7"
      echo $SYS_VER
    elif [[ $SYS_VER =~ "debian-11" ]]; then
      SYS_VER="debian-11"
      echo $SYS_VER

    else  
      echo "目前只支持ubuntu-16.04、ubuntu-22.04、debian-11和Centos-7"
      exit 1
    fi
}

get_auth() {
    # 保存auth code
    curl -v -m 10 -k --resolve $MASTER_HOST:88:$MASTER_IP  -H "Host: $MASTER_HOST"  http://$MASTER_HOST:88/auth-code -H "es-pwd: $ES_PWD" -o /opt/.auth_code
}

# 检查系统
need_sys

# 解析命令行参数
TEMP=`getopt -o h --long help,master-ip:,master-host:,es-ip:,es-pwd:,ignore-ntp -- "$@"`
if [ $? != 0 ] ; then echo "Terminating..." >&2 ; exit 1 ; fi
eval set -- "$TEMP"

ignore_ntp=false
while true ; do
    case "$1" in
        -h|--help) help ; exit 1 ;;
        --master-ip) MASTER_IP=$2 ; shift 2 ;;
        --master-host) MASTER_HOST=$2 ; shift 2 ;;
        --es-ip) ES_IP=$2 ; shift 2 ;;
        --es-pwd) ES_PWD=$2 ; shift 2 ;;
        --ignore-ntp) ignore_ntp=true; shift 1;;
        --) shift ; break ;;
        *) echo "Internal error!" ; exit 1 ;;
    esac
done

if [[ "$MASTER_IP" == "" ]]; then
    echo "please specify master ip with --master-ip 1.1.1.1 "
    exit 1
fi

if [[ "$ES_IP" == "" ]]; then
    echo "please specify elasticsearch ip with --es-ip 1.1.1.1 "
    exit 1
fi

if [[ "$ES_PWD" == "" ]]; then
    echo "please specify elasticsearch password with --es-pwd xxx "
    exit 1
fi

# 禁止安装节点到主控
if [[ -d "/opt/cdnfly/master" ]];then 
    echo "存在/opt/cdnfly/master，当前的机器可能是主控，请勿安装节点程序"
    exit 1
fi

get_auth
sync_time
install_depend
install_python_module
install_openresty
install_redis
install_filebeat
install_rsyslog
config
start

