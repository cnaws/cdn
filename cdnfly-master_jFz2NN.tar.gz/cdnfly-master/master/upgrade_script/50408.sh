#!/bin/bash

set -o errexit

download(){
  # wget安装
  if [[ ! `which wget` ]]; then
    if check_sys sysRelease ubuntu;then
        apt-get install -y wget
    elif check_sys sysRelease centos;then
        yum install -y wget
    fi 
  fi

  local url1=$1
  local url2=$2
  local filename=$3
  
  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url=$url1
  if [[ $speed2 -gt $speed1 ]]; then
    url=$url2
  fi
  echo "using url:"$url
  wget "$url" -O $filename

}

#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}


upgrade_db() {
supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf stop cc_auto_switch node_monitor site_res_count site_sync task

cat > /tmp/_db.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
sys.path.append("/opt/cdnfly/master/")
from model.db import Db
import pymysql
import json
reload(sys) 
import re
sys.setdefaultencoding('utf8')

conn = Db()
try:
    # 恢复uid 1的用户
    user_row = conn.fetchone("select * from user where id=1 ")
    if not user_row:
        conn.execute("insert into user values (1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,2)")
        conn.commit()


    # SMSBAO_URL填充
    with open("/opt/cdnfly/master/conf/config.py") as fp:
        data = fp.read()

    match = re.match(r'.*SMSBAO_URL\s*=\s*"(.*?)".*',data,re.S)
    if match:
        smsbao_url = match.groups()[0]
    else:
        smsbao_url = "http://api.smsbao.com/sms"

    sms_config = json.loads(conn.fetchone("select value from config where name='sms_config' ")['value'])
    sms_config["smsbao_url"] = smsbao_url
    conn.execute("update config set value =%s where name='sms_config' ", json.dumps(sms_config))
    conn.commit()

    # built_in_white spider_ip
    openresty_config = json.loads(conn.fetchone("select value from config where name='openresty-config'  and scope_name='global' ")['value'])
    openresty_config['built_in_white'] = ["45.33.99.204","139.162.76.111","192.46.226.104","45.79.81.228","49.7.135.3","119.96.229.174","129.28.14.61","111.13.102.10","183.232.11.38","125.39.179.198","211.90.241.52","112.91.140.167"]
    openresty_config['spider_ip'] = {"40.77.195": 1, "40.77.194": 1, "40.77.191": 1, "65.52.109": 1, "40.77.193": 1, "40.77.192": 1, "34.154.114.153": 1, "34.154.114.152": 1, "34.154.114.150": 1, "154.12.224.26": 1, "220.243.189": 1, "40.77.190": 1, "40.77.168": 1, "40.77.169": 1, "40.77.160": 1, "123.183.224": 1, "40.77.162": 1, "40.77.163": 1, "40.77.164": 1, "40.77.165": 1, "40.77.166": 1, "40.77.167": 1, "34.88.194": 1, "20.36.108": 1, "61.135.169.19": 1, "34.80.50.89": 1, "34.65.242": 1, "217.156.87.14": 1, "157.55.50": 1, "40.90.149": 1, "40.90.148": 1, "40.90.147": 1, "40.90.146": 1, "40.90.145": 1, "40.90.144": 1, "65.55.230.252": 1, "51.4.84": 1, "65.55.230.250": 1, "40.77.223": 1, "40.77.222": 1, "40.77.221": 1, "40.77.220": 1, "34.64.82": 1, "13.67.10": 1, "207.46.12.72": 1, "218.30.103": 1, "23.103.64": 1, "65.54.164": 1, "207.68.185.33": 1, "40.77.161": 1, "106.11.157": 1, "106.11.156": 1, "106.11.155": 1, "106.11.154": 1, "106.11.153": 1, "106.11.152": 1, "207.46.13": 1, "34.175.160.73": 1, "34.175.160.72": 1, "34.175.160.70": 1, "106.11.159": 1, "106.11.158": 1, "109.238.6.49": 1, "109.238.6.46": 1, "61.135.158.81": 1, "220.243.136": 1, "220.243.135": 1, "40.79.186": 1, "217.156.87.5": 1, "110.249.201": 1, "110.249.202": 1, "131.253.46.111": 1, "34.80.50.87": 1, "106.120.188.69": 1, "40.90.11": 1, "111.221.28": 1, "42.159.48": 1, "34.118.254": 1, "199.30.31": 1, "202.89.235": 1, "111.206.221": 1, "104.44.93": 1, "104.44.92": 1, "104.44.91": 1, "64.4.22": 1, "36.110.147.71": 1, "36.110.147.70": 1, "157.55.154": 1, "42.236.46": 1, "34.80.50.84": 1, "157.56.93": 1, "34.80.50.83": 1, "123.125.125.179": 1, "42.236.49": 1, "34.126.178.108": 1, "42.236.99": 1, "65.55.189": 1, "199.188.107.107": 1, "34.126.178.101": 1, "34.126.178.100": 1, "34.126.178.103": 1, "131.253.35": 1, "34.126.178.105": 1, "34.126.178.104": 1, "34.126.178.107": 1, "34.126.178.106": 1, "157.56.71": 1, "34.146.150": 1, "134.195.209.96": 1, "61.135.169.52": 1, "61.135.169.53": 1, "220.243.188": 1, "178.20.236": 1, "61.135.168": 1, "123.125.125.182": 1, "65.55.230.225": 1, "40.77.186": 1, "40.77.187": 1, "40.77.184": 1, "40.77.185": 1, "40.77.182": 1, "40.77.183": 1, "40.77.180": 1, "40.77.181": 1, "40.77.188": 1, "40.77.189": 1, "42.236.101": 1, "42.236.102": 1, "42.236.103": 1, "20.74.197": 1, "35.247.243.246": 1, "35.247.243.247": 1, "35.247.243.244": 1, "35.247.243.245": 1, "35.247.243.242": 1, "35.247.243.240": 1, "35.247.243.241": 1, "199.30.30": 1, "35.247.243.248": 1, "35.247.243.249": 1, "20.15.133": 1, "106.38.241": 1, "207.46.126": 1, "131.253.46.223": 1, "157.56.2": 1, "157.56.3": 1, "157.56.0": 1, "157.56.1": 1, "20.43.120": 1, "34.100.182": 1, "40.77.248": 1, "34.154.114.147": 1, "40.90.150": 1, "40.90.151": 1, "40.90.152": 1, "40.90.153": 1, "40.90.154": 1, "40.90.155": 1, "40.90.156": 1, "40.90.157": 1, "40.90.158": 1, "42.120.234": 1, "42.120.235": 1, "42.120.236": 1, "61.135.165.19": 1, "49.7.116": 1, "49.7.117": 1, "13.71.172": 1, "40.90.8": 1, "207.68.176.142": 1, "207.68.176.141": 1, "118.184.177": 1, "66.249.79": 1, "66.249.78": 1, "66.249.71": 1, "66.249.70": 1, "66.249.73": 1, "66.249.72": 1, "66.249.75": 1, "66.249.74": 1, "66.249.77": 1, "66.249.76": 1, "191.232.136.48": 1, "220.181.32": 1, "34.175.160.64": 1, "34.175.160.65": 1, "60.8.123": 1, "180.76.15": 1, "191.232.136.172": 1, "34.175.160.68": 1, "34.175.160.69": 1, "43.231.99": 1, "207.68.146.215": 1, "192.178.5": 1, "61.135.159": 1, "131.253.46.125": 1, "131.253.46.126": 1, "34.175.160.66": 1, "34.165.18": 1, "65.54.247": 1, "34.175.160.67": 1, "40.66.1": 1, "180.153.232": 1, "40.66.4": 1, "34.118.66.14": 1, "34.118.66.15": 1, "34.118.66.13": 1, "34.118.66.10": 1, "34.118.66.11": 1, "51.5.84": 1, "123.125.186.10": 1, "123.125.186.11": 1, "123.125.186.12": 1, "34.152.50": 1, "40.77.209": 1, "40.77.208": 1, "42.159.176": 1, "220.181.108": 1, "34.155.98.35": 1, "34.155.98.36": 1, "61.135.165.53": 1, "103.255.141": 1, "42.236.48": 1, "154.12.224.161": 1, "157.55.39": 1, "191.232.136.86": 1, "65.55.230.253": 1, "180.76.5": 1, "134.195.209.4": 1, "36.110.147.68": 1, "36.110.147.69": 1, "193.234.60.17": 1, "111.206.198": 1, "36.110.147.64": 1, "36.110.147.65": 1, "36.110.147.66": 1, "36.110.147.67": 1, "34.126.178.102": 1, "104.47.224": 1, "42.120.160": 1, "42.120.161": 1, "34.80.50.85": 1, "123.126.113": 1, "131.253.36": 1, "34.80.50.82": 1, "34.80.50.81": 1, "103.25.156": 1, "123.125.125.184": 1, "131.253.38": 1, "123.125.125.181": 1, "113.24.225": 1, "40.79.131": 1, "61.135.169.20": 1, "61.135.165.20": 1, "65.55.107": 1, "131.253.46.221": 1, "131.253.46.224": 1, "191.232.136.216": 1, "34.147.110": 1, "49.7.21": 1, "49.7.20": 1, "180.153.234": 1, "180.153.236": 1, "207.68.146.222": 1, "207.68.146.221": 1, "111.225.148": 1, "111.225.149": 1, "65.55.219": 1, "65.55.218": 1, "65.55.213": 1, "65.55.212": 1, "65.55.211": 1, "65.55.210": 1, "65.55.217": 1, "65.55.216": 1, "65.55.215": 1, "65.55.214": 1, "199.30.17": 1, "199.30.18": 1, "199.30.19": 1, "203.208.60": 1, "123.125.66": 1, "199.30.26": 1, "191.233.204": 1, "40.77.252": 1, "40.77.253": 1, "40.77.250": 1, "40.77.251": 1, "180.149.133": 1, "40.77.254": 1, "104.44.253": 1, "111.221.31": 1, "180.163.220": 1, "13.66.144": 1, "116.179.32": 1, "66.249.69": 1, "124.166.232": 1, "34.118.66.1": 1, "34.118.66.2": 1, "116.179.37": 1, "106.120.173": 1, "66.249.66": 1, "66.249.64": 1, "66.249.65": 1, "65.55.146": 1, "123.125.125.151": 1, "61.135.189": 1, "60.8.151": 1, "42.236.16": 1, "51.105.67": 1, "64.68.88": 1, "42.236.15": 1, "42.236.14": 1, "34.151.74": 1, "207.68.155": 1, "13.66.139": 1, "40.77.179": 1, "34.154.114.148": 1, "34.154.114.149": 1, "34.154.114.144": 1, "34.154.114.145": 1, "34.154.114.146": 1, "65.52.110": 1, "42.156.255": 1, "42.156.254": 1, "61.135.186": 1, "40.77.177": 1, "40.77.176": 1, "40.77.175": 1, "40.77.174": 1, "40.77.173": 1, "40.77.172": 1, "40.77.171": 1, "40.77.170": 1, "34.96.162": 1, "40.77.178": 1, "40.77.216": 1, "40.77.217": 1, "40.77.214": 1, "40.77.215": 1, "40.77.212": 1, "40.77.213": 1, "40.77.210": 1, "40.77.211": 1, "40.77.218": 1, "40.77.219": 1, "34.176.130": 1, "61.49.160.21": 1, "61.49.160.20": 1, "42.236.50": 1, "194.32.107.227": 1, "194.32.107.226": 1, "154.53.40.69": 1, "154.53.40.63": 1, "42.236.17": 1, "157.55.21": 1, "157.55.22": 1, "157.55.23": 1, "42.236.13": 1, "42.236.12": 1, "42.236.10": 1, "65.55.25": 1, "40.77.255": 1, "207.68.185.56": 1, "123.126.68": 1, "131.253.47.190": 1, "34.89.198": 1, "207.46.199": 1, "131.253.25": 1, "131.253.24": 1, "131.253.27": 1, "131.253.26": 1, "157.55.2": 1, "157.55.7": 1, "42.156.138": 1, "42.156.139": 1, "52.167.144": 1, "42.156.137": 1, "40.73.148": 1, "157.55.103": 1, "58.250.125": 1, "157.55.106": 1, "157.55.107": 1, "207.46.12.79": 1, "207.46.12.78": 1, "207.46.12.75": 1, "207.46.12.74": 1, "207.46.12.77": 1, "207.46.12.76": 1, "207.46.12.73": 1, "193.234.60.18": 1, "154.53.40.3": 1, "154.53.40.2": 1, "20.79.107": 1, "65.55.208": 1, "65.55.209": 1, "106.120.188.72": 1, "106.120.188.73": 1, "106.120.188.70": 1, "106.120.188.71": 1, "106.120.188.76": 1, "106.120.188.74": 1, "106.120.188.75": 1, "61.135.165.52": 1, "123.125.71": 1, "123.125.109": 1, "34.89.10.86": 1, "34.89.10.84": 1, "34.89.10.82": 1, "34.89.10.83": 1, "34.89.10.80": 1, "34.89.10.81": 1, "34.89.10.88": 1, "34.89.10.89": 1, "220.181.124": 1, "220.181.125": 1, "34.118.66.3": 1, "199.30.29": 1, "199.30.28": 1, "199.30.23": 1, "199.30.22": 1, "199.30.21": 1, "199.30.20": 1, "199.30.27": 1, "61.49.160.19": 1, "199.30.25": 1, "199.30.24": 1, "34.101.50": 1, "207.68.176.163": 1, "207.68.176.164": 1, "157.55.10": 1, "157.55.13": 1, "157.55.12": 1, "34.22.85.0": 1, "34.22.85.1": 1, "34.22.85.2": 1, "34.22.85.3": 1, "111.202.101": 1, "111.202.100": 1, "111.202.103": 1, "34.80.50.80": 1, "65.55.54": 1, "42.236.53": 1, "42.236.52": 1, "42.236.51": 1, "131.253.47.148": 1, "42.236.55": 1, "42.236.54": 1, "131.253.47.147": 1, "199.188.107.110": 1, "64.68.92": 1, "64.68.91": 1, "64.68.90": 1, "13.69.66": 1, "61.135.158.72": 1, "66.249.68": 1, "109.238.6.19": 1, "34.118.66.0": 1, "42.156.136": 1}
    openresty_config['click_html'] = openresty_config['click_html'].replace("<input style='margin-top: 20px;' id='access' type='button' class='btn btn-success' value='进入网站'>","<button style='margin-top: 20px;' id='access' class='btn btn-success'>进入网站</button>")

    conn.execute("update config set value=%s where name='openresty-config'  and scope_name='global' ",json.dumps(openresty_config))
    conn.commit()

    # spider_allow
    if not conn.fetchone("select * from config where name='spider_allow' "):
        conn.execute("insert into config values ('spider_allow','allow','site_default_config','0','global', now(),now(),1,null)")
        conn.commit()

    conn.execute("update site set spider_allow='allow'; ")
    conn.commit()



except:
    conn.rollback()
    raise

finally:
    conn.close()
EOF

/opt/venv/bin/python /tmp/_db.py


# 手机三要素
cd /tmp
download "https://dl2.cdnfly.cn/cdnfly/aliyun_python_sdk_dysmsapi-2.1.2-py2.py3-none-any.whl" "https://us.centos.bz/cdnfly/aliyun_python_sdk_dysmsapi-2.1.2-py2.py3-none-any.whl" "aliyun_python_sdk_dysmsapi-2.1.2-py2.py3-none-any.whl"
/opt/venv/bin/pip install aliyun_python_sdk_dysmsapi-2.1.2-py2.py3-none-any.whl 


# nginx_access_pipeline
eval `grep LOG_IP /opt/cdnfly/master/conf/config.py`
eval `grep LOG_PWD /opt/cdnfly/master/conf/config.py`

curl -u elastic:$LOG_PWD -X PUT "$LOG_IP:9200/_ingest/pipeline/nginx_access_pipeline?pretty" -H 'Content-Type: application/json' -d'
{
  "description" : "nginx access pipeline",
  "processors" : [
      {
        "dissect": {
          "field": "message",
          "ignore_failure": true,
          "pattern" : "%{nid}\t%{uid}\t%{upid}\t%{site_id}\t%{time}\t%{addr}\t%{method}\t%{scheme}\t%{host}\t%{server_port}\t%{req_uri}\t%{protocol}\t%{status}\t%{bytes_sent}\t%{referer}\t%{user_agent}\t%{content_type}\t%{up_resp_time}\t%{cache_status}\t%{up_recv}\t%{country}\t%{province}\t%{city}"
         }
      },
      {
          "remove": {
            "field": "message"
          }      
      },
      {
        "script": { 
          "lang":   "painless",
          "ignore_failure": true,
          "source": "if (ctx[\u0027scheme\u0027] == \"http\") {ctx[\u0027bytes_sent\u0027] = Integer.parseInt(ctx[\u0027bytes_sent\u0027]) + 300} else { ctx[\u0027bytes_sent\u0027] = Integer.parseInt(ctx[\u0027bytes_sent\u0027]) + 5300 }  "
        }

      }             
  ],
    "on_failure" : [
    {
      "set" : {
        "field" : "_index",
        "value" : "failed-{{ _index }}"
      }
    }
  ]  
}
'

curl -u elastic:$LOG_PWD  -X PUT "$LOG_IP:9200/_template/http_access_template" -H 'Content-Type: application/json' -d'
{
  "mappings": {
    "properties": {
      "nid":    { "type": "keyword" },  
      "uid":    { "type": "keyword" },  
      "upid":    { "type": "keyword" },  
      "site_id":    { "type": "keyword" }, 
      "time":   { "type": "date"  ,"format":"dd/MMM/yyyy:HH:mm:ss Z"},
      "addr":  { "type": "keyword"  }, 
      "method":  { "type": "text" , "index":false }, 
      "scheme":  { "type": "keyword"  }, 
      "host":  { "type": "keyword"  }, 
      "server_port":  { "type": "keyword"  }, 
      "req_uri":  { "type": "keyword"  }, 
      "protocol":  { "type": "text" , "index":false }, 
      "status":  { "type": "keyword"  }, 
      "bytes_sent":  { "type": "integer"  }, 
      "referer":  { "type": "keyword"  }, 
      "user_agent":  { "type": "text" , "index":false }, 
      "content_type":  { "type": "text" , "index":false }, 
      "up_resp_time":  { "type": "float" , "index":false,"ignore_malformed": true }, 
      "cache_status":  { "type": "keyword"  }, 
      "up_recv":  { "type": "integer", "index":false,"ignore_malformed": true  },
      "country":  { "type": "keyword"  }, 
      "province":  { "type": "keyword" }, 
      "city":  { "type": "text" , "index":false }
    }
  },  
  "index_patterns": ["http_access-*"], 
  "settings": {
    "number_of_shards": 1,
    "number_of_replicas": 0,
    "index.lifecycle.name": "access_log_policy", 
    "index.lifecycle.rollover_alias": "http_access"
  }
}
'
# 当前index改mappings
curl -s  -u elastic:$LOG_PWD  -X GET http://$LOG_IP:9200/_cat/indices/http_access-* | awk '{print $3}' | while read index;do
    curl -u elastic:$LOG_PWD  -XPUT "http://$LOG_IP:9200/$index/_mapping?pretty" -H 'Content-Type: application/json' -d '
    {
        "properties":{
            "country":  { "type": "keyword"  }, 
            "province": { "type": "keyword" }, 
            "city":  { "type": "text" , "index":false }
        }
    }
    '
done


curl -u elastic:$LOG_PWD  -X PUT "$LOG_IP:9200/black_ip/_mapping" -H 'Content-Type: application/json' -d'
{
    "properties": {
      "position":  { "type": "keyword"  }
  }
}
'


# 更新panel或conf
flist='master/panel/console/index.html
master/panel/src/views/account/personal/index.html
master/panel/src/views/config/default/index.html
master/panel/src/views/node/node/node-log.html
master/panel/src/views/site/acl/acl-add.html
master/panel/src/views/site/acl/acllist-add.html
master/panel/src/views/site/cc/match-add.html
master/panel/src/views/site/cc/matchlist-add.html
master/panel/src/views/site/cc/rule.html
master/panel/src/views/site/monitor/access-log.html
master/panel/src/views/site/monitor/blackip.html
master/panel/src/views/site/monitor/top-res.html
master/panel/src/views/site/site/edit.html
master/panel/src/views/site/site/index.html
master/panel/src/views/site/site/update_form.html
master/panel/src/views/site/site/url_ratelimit_form.html
master/panel/src/views/site/site/url_rewrite_form.html
master/panel/src/views/system/config/index.html
master/panel/src/views/system/op/index.html
master/panel/src/views/user_config/site/addform.html
master/panel/src/views/user_config/site/index.html
master/conf/nginx_global.tpl
master/conf/nginx_http_default.tpl
master/conf/nginx_http_vhost.tpl'

for f in `echo $flist`;do
\cp -a /opt/$dir_name/$f /opt/cdnfly/$f
done

}

update_file() {
cd /opt/$dir_name/master/
for i in `find ./ | grep -vE "^./$|^./agent$|^./conf$|conf/config.py|conf/nginx_global.tpl|conf/supervisord.conf|conf/supervisor_master.conf|conf/nginx_http_default.tpl|conf/nginx_http_vhost.tpl|conf/nginx_stream_vhost.tpl|conf/ssl.cert|conf/ssl.key|^./panel"`;do
    \cp -aT $i /opt/cdnfly/master/$i
done

}

# 定义版本
version_name="v5.4.8"
version_num="50408"
dir_name="cdnfly-master-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

cd /opt
echo "准备升级数据库..."
upgrade_db
echo "升级数据库完成"

echo "更新文件..."
update_file
echo "更新文件完成." 

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/master/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/master/conf/config.py
rm -f /opt/cdnfly/master/conf/config.pyc
echo "修改完成"

echo "开始重启主控..."
supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf restart all
#supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf reload
echo "重启完成"

echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"