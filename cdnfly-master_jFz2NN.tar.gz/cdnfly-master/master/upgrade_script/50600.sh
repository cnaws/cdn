#!/bin/bash

set -o errexit

download(){
  # wget安装
  if [[ ! `which wget` ]]; then
    if check_sys sysRelease ubuntu;then
        apt-get install -y wget
    elif check_sys sysRelease centos;then
        yum install -y wget
    fi 
  fi

  local url1=$1
  local url2=$2
  local filename=$3
  
  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url=$url1
  if [[ $speed2 -gt $speed1 ]]; then
    url=$url2
  fi
  echo "using url:"$url
  wget "$url" -O $filename

}

#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}


upgrade_db() {
eval `grep MYSQL_PASS /opt/cdnfly/master/conf/config.py`
eval `grep MYSQL_IP /opt/cdnfly/master/conf/config.py`
eval `grep MYSQL_PORT /opt/cdnfly/master/conf/config.py`
eval `grep MYSQL_DB /opt/cdnfly/master/conf/config.py`
eval `grep MYSQL_USER /opt/cdnfly/master/conf/config.py`

# 开启维护模式
mysql -h$MYSQL_IP -u$MYSQL_USER -p$MYSQL_PASS -P$MYSQL_PORT $MYSQL_DB -e "update config set value='{\"enable\":1,\"msg\":\"系统升级中,请稍候重试\"}' where name='maintain' " 

supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf status | grep -v master | awk '{print $1}' | xargs supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf stop 

# 备份site_conf_cache表
mysqldump -h$MYSQL_IP -u$MYSQL_USER -p$MYSQL_PASS -P$MYSQL_PORT $MYSQL_DB site_conf_cache > /opt/site_conf_cache.sql

# 备份master
if [[ ! -d /opt/cdnfly-50507-bak ]];then
    \cp -a /opt/cdnfly /opt/cdnfly-50507-bak
fi

mysql -N -uroot -p$MYSQL_PASS cdn -e 'show processlist' | awk '{print $1}' | xargs kill || true

# elasticsearch
# nginx_access_pipeline
eval `grep LOG_IP /opt/cdnfly/master/conf/config.py`
eval `grep LOG_PWD /opt/cdnfly/master/conf/config.py`

curl -u elastic:$LOG_PWD -X PUT "$LOG_IP:9200/_ingest/pipeline/nginx_access_pipeline?pretty" -H 'Content-Type: application/json' -d'
{
  "description" : "nginx access pipeline",
  "processors" : [
      {
        "dissect": {
          "field": "message",
          "ignore_failure": true,
          "pattern" : "%{nid}\t%{uid}\t%{upid}\t%{site_id}\t%{time}\t%{addr}\t%{method}\t%{scheme}\t%{host}\t%{host2}\t%{server_port}\t%{req_uri}\t%{protocol}\t%{status}\t%{bytes_sent}\t%{referer}\t%{user_agent}\t%{content_type}\t%{up_resp_time}\t%{cache_status}\t%{up_recv}\t%{country}\t%{province}\t%{city}"
         }
      },
      {
          "remove": {
            "field": "message"
          }      
      },
      {
        "script": { 
          "lang":   "painless",
          "ignore_failure": true,
          "source": "if (ctx[\u0027scheme\u0027] == \"http\") {ctx[\u0027bytes_sent\u0027] = Integer.parseInt(ctx[\u0027bytes_sent\u0027]) + 300} else { ctx[\u0027bytes_sent\u0027] = Integer.parseInt(ctx[\u0027bytes_sent\u0027]) + 5300 }  "
        }

      }             
  ],
    "on_failure" : [
    {
      "set" : {
        "field" : "_index",
        "value" : "failed-{{ _index }}"
      }
    }
  ]  
}
'

curl -u elastic:$LOG_PWD  -X PUT "$LOG_IP:9200/_template/http_access_template" -H 'Content-Type: application/json' -d'
{
  "mappings": {
    "properties": {
      "nid":    { "type": "keyword" },  
      "uid":    { "type": "keyword" },  
      "upid":    { "type": "keyword" },  
      "site_id":    { "type": "keyword" }, 
      "time":   { "type": "date"  ,"format":"dd/MMM/yyyy:HH:mm:ss Z"},
      "addr":  { "type": "keyword"  }, 
      "method":  { "type": "text" , "index":false }, 
      "scheme":  { "type": "keyword"  }, 
      "host":  { "type": "keyword"  }, 
      "host2":  { "type": "text" , "index":false }, 
      "server_port":  { "type": "keyword"  }, 
      "req_uri":  { "type": "keyword"  }, 
      "protocol":  { "type": "text" , "index":false }, 
      "status":  { "type": "keyword"  }, 
      "bytes_sent":  { "type": "integer"  }, 
      "referer":  { "type": "keyword"  }, 
      "user_agent":  { "type": "text" , "index":false }, 
      "content_type":  { "type": "text" , "index":false }, 
      "up_resp_time":  { "type": "float" , "index":false,"ignore_malformed": true }, 
      "cache_status":  { "type": "keyword"  }, 
      "up_recv":  { "type": "integer", "index":false,"ignore_malformed": true  },
      "country":  { "type": "keyword"  }, 
      "province":  { "type": "keyword" }, 
      "city":  { "type": "text" , "index":false }
    }
  },  
  "index_patterns": ["http_access-*"], 
  "settings": {
    "number_of_shards": 1,
    "number_of_replicas": 0,
    "index.lifecycle.name": "access_log_policy", 
    "index.lifecycle.rollover_alias": "http_access"
  }
}
'
# 当前index改mappings
curl -s  -u elastic:$LOG_PWD  -X GET http://$LOG_IP:9200/_cat/indices/http_access-* | awk '{print $3}' | while read index;do
    curl -u elastic:$LOG_PWD  -XPUT "http://$LOG_IP:9200/$index/_mapping?pretty" -H 'Content-Type: application/json' -d '
    {
        "properties":{
          "host2":  { "type": "text" , "index":false }
        }
    }
    '
done

cat > /tmp/_db.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
sys.path.append("/opt/cdnfly/master/")
from model.db import Db
from view.util import is_ip, is_ipv6, get_md5,escape_re_str,is_empty
from conf.config import ALLOW_HOSTS
from jinja2 import Template
import pymysql
import json
reload(sys) 
import os
import tarfile
import base64
sys.setdefaultencoding('utf8')

conn = Db()
try:
    # 设置site的https_listen.http3为0
    sites = conn.fetchall("select id,https_listen from site")
    for site in sites:
        https_listen = json.loads(site['https_listen'])
        if https_listen:
            https_listen['http3'] = 0
        
        conn.execute("update site set https_listen=%s where id=%s", (json.dumps(https_listen), site['id'], ) )
    conn.commit()

    # http3默认值
    if not conn.fetchone("select * from config where type='site_default_config' and name='https_listen-http3' "):
        conn.execute("insert into config values ('https_listen-http3','0','site_default_config','0','global', now(),now(),1,null) ")
        conn.commit()

    # proxy_connect_timeout默认值
    if not conn.fetchone("select * from config where type='site_default_config' and name='proxy_connect_timeout' "):
        conn.execute("insert into config values ('proxy_connect_timeout','10','site_default_config','0','global', now(),now(),1,null) ")
        conn.commit()

    # site的proxy_connect_timeout
    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'proxy_connect_timeout' "):
        conn.execute("alter table site add proxy_connect_timeout varchar(3) default 10 after proxy_timeout ")
        conn.commit()
    
    # proxy_timeout扩大
    conn.execute("alter table site modify proxy_timeout varchar(10)")
    conn.commit()

    # 只有iphash和rr了
    conn.execute("update site set balance_way='rr' where balance_way != 'ip_hash'")
    conn.execute("update stream set balance_way='rr' where balance_way != 'ip_hash'")
    conn.commit()


    # 错误页
    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'page_403' "):
        conn.execute("alter table site add page_403 text after req_header ")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'page_500' "):
        conn.execute("alter table site add page_500 text after page_404 ")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'page_502' "):
        conn.execute("alter table site add page_502 text after page_500")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'page_504' "):
        conn.execute("alter table site add page_504 text after page_502")
        conn.commit()


    if conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'page_50x' "):
        conn.execute("update site set page_500=page_50x, page_502=page_50x, page_504=page_50x ")
        conn.execute("alter table site drop page_50x")
        conn.commit()

    
    # 四层区域屏蔽
    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'stream' AND column_name = 'block_region' "):
        conn.execute("alter table stream add block_region text after acl")
        conn.commit()

    conn.execute("update stream set block_region = '' ")
    conn.commit()

    # 套餐中的http3
    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'package' AND column_name = 'http3' "):
        conn.execute("alter table package add http3 boolean default false after websocket")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'user_package' AND column_name = 'http3' "):
        conn.execute("alter table user_package add http3 boolean default false after websocket")
        conn.commit()


    # 遍历nginx-config-file,把resolver，迁移到openresty-file 
    nginx_configs = conn.fetchall("select * from config where name='nginx-config-file' and type='nginx_config' ")
    for n in nginx_configs:
        scope_name = n['scope_name']
        scope_id = n['scope_id']
        value = json.loads(n['value'])
        if 'resolver' not in value:
            continue
            
        resolver = value['resolver']

        openresty = {"resolver": resolver}
        openresty_config = conn.fetchone("select * from config where name='openresty-config' and type='openresty_config' and scope_name=%s and scope_id=%s ", (scope_name,scope_id,) )
        if openresty_config:
            openresty.update(json.loads(openresty_config['value']))
        
        conn.execute("update config set value=%s where name='openresty-config' and type='openresty_config' and scope_name=%s and scope_id=%s ",(json.dumps(openresty),scope_name,scope_id,  ) )
        conn.commit()

    # config.http.client_max_body_size设置为2g
    # proxy_cache_keys_zone_size改为auto
    nginx_config = json.loads(conn.fetchone("select * from config where name='nginx-config-file' and type='nginx_config' and scope_name = 'global' ")['value'])
    nginx_config['http']['client_max_body_size'] = '2g'
    conn.execute("update config set value=%s where name='nginx-config-file' and type='nginx_config' and scope_name='global'  ",(json.dumps(nginx_config),  ) )
    conn.commit()    

    # conf目录:
    # listen_other.conf
    # listen_80.conf
    # 获得所有监听的端口，并去重

    def render_listen_conf(site):
        tpl_file = "/opt/cdnfly-master-v5.6.0/master/conf/nginx_http_default.tpl"
        with open(tpl_file) as fp:
            tpl = fp.read()
        
        # 获取ALLOW_HOSTS
        master_host = ""
        if not is_empty(ALLOW_HOSTS):
            master_host = ALLOW_HOSTS.split()[0]

        template = Template(tpl)
        return template.render(site=site,master_host=master_host)

    def gen_config(conn, config_type, config_name, region_id, node_id):
        ## 全局配置
        value = json.loads(conn.fetchone("select name, value, type from config where type=%s and name=%s and scope_name='global' ", (config_type,config_name,) )['value'])
        
        ## 区域配置
        region_config = conn.fetchone("select name, value, type from config where type=%s and name=%s and scope_name='region' and scope_id=%s ", (config_type,config_name,region_id, ) )
        if region_config:
            region_config = json.loads(region_config['value'])
            for k in region_config:
                v = region_config[k]
                if isinstance(v,dict):
                    for k2 in v:
                        v2 = v[k2]
                        if not v2:
                            continue

                        value[k][k2] = v2

                    if not value[k]:
                        continue

                    v = value[k]

                if not v:
                    continue

                value[k] = v

        ## 节点配置
        node_config = conn.fetchone("select name, value, type from config where type=%s and name=%s and scope_name='node' and scope_id=%s ", (config_type,config_name,node_id, ) )
        if node_config:
            node_config = json.loads(node_config['value'])
            
            for k in node_config:
                v = node_config[k]
                if isinstance(v,dict):
                    for k2 in v:
                        v2 = v[k2]
                        if not v2:
                            continue

                        value[k][k2] = v2

                    if not value[k]:
                        continue

                    v = value[k]

                if not v:
                    continue

                value[k] = v    

        return value

    def render_site(site):
        site_id = site['id']
        # http_listen
        site['http_listen'] = json.loads(site['http_listen'])

        # port 
        if site['http_listen']:
            site['http_listen']['ports'] = str(site['http_listen']['port']).split()

        # https_listen
        site['https_listen'] = json.loads(site['https_listen'])

        # port 
        if site['https_listen']:
            site['https_listen']['ports'] = str(site['https_listen']['port']).split()
            site['https_listen']['ssl_protocols_arr'] = site['https_listen']['ssl_protocols'].split()

        # balance_way
        if site['balance_way'] == "url_hash":
            site['balance_way'] = "hash $uri consistent"

        # proxy_cache 1.根据no_cache生成site.maps 2. 根据type,content生成location匹配 site.cache
        proxy_cache = json.loads(site['proxy_cache'])
        cache = []
        maps = []
        no_cache_arr = {}
        for i in range(len(proxy_cache)):
            p_type = proxy_cache[i]['type']
            content = proxy_cache[i]['content']
            expire = int(proxy_cache[i]['expire'])
            unit = proxy_cache[i]['unit']
            ignore_arg = proxy_cache[i]['ignore_arg']
            proxy_ignore_headers = proxy_cache[i]['proxy_ignore_headers']
            no_cache = proxy_cache[i]['no_cache']
            cache_range = proxy_cache[i]['range']

            # cache
            if p_type == "suffix":
                content = escape_re_str(content)
                uri = "\.({content})$".format(content=content)

            elif p_type == "dir":
                # 转义正则字符及分号,只保留通配符功能
                content = escape_re_str(content)
                content = content.replace(";","\;")
                content = content.replace('\\*','.*?')   
                uri = content

            elif p_type == "full_path":
                # 转义正则字符及分号,只保留通配符功能
                content = escape_re_str(content)
                content = content.replace(";","\;")
                content = content.replace('\\*','.*?')
                uri = "^{content}$".format(content=content)    

            # 允许|
            uri = uri.replace('\\|','|')
            if unit == "h":
                expire = expire * 3600
            elif unit == "d":
                expire = expire * 3600 * 24

            cache.append({"range":cache_range, "uri":uri,"ignore_arg":int(ignore_arg),"expire":expire,"proxy_ignore_headers":proxy_ignore_headers.split(), "no_cache":no_cache })

        site['maps'] = maps
        site['cache'] = cache

        # resp_header
        resp_header = json.loads(site['resp_header'])
        for i in range(len(resp_header)):
            # 转义\
            resp_header[i]['name'] = resp_header[i]['name'].replace('\\','\\\\')
            resp_header[i]['value'] = resp_header[i]['value'].replace('\\','\\\\')

            # 转义双引号
            resp_header[i]['name'] = resp_header[i]['name'].replace('"','\\"')
            resp_header[i]['value'] = resp_header[i]['value'].replace('"','\\"')

            # 转义$
            if not resp_header[i]['value'].startswith("$") and resp_header[i]['value'].find("$") > -1:
                resp_header[i]['value'] = resp_header[i]['value'].replace('$','${dollar}')

        site['resp_header'] = resp_header
        
        # req_header
        req_header = json.loads(site['req_header'])
        site['req_header'] = req_header

        # cors
        cors = json.loads(site['cors'])
        cors['allow_origin'] = "|".join(cors['allow_origin'].split())
        cors['allow_methods'] = ", ".join(cors['allow_methods'].split())
        cors['allow_headers'] = ", ".join(cors['allow_headers'].split()).replace('\\','\\\\').replace('"','\\"')
        cors['expose_headers'] = ", ".join(cors['expose_headers'].split()).replace('\\','\\\\').replace('"','\\"')

        site['cors'] = cors

        # url_rewrite
        site['url_rewrite'] = json.loads(site['url_rewrite'])
        for i in range(len(site['url_rewrite'])):
            host = site['url_rewrite'][i]['host'] # 1
            country_code = site['url_rewrite'][i]['country_code'] # 2
            referer = site['url_rewrite'][i]['referer'] # 3
            user_agent = site['url_rewrite'][i]['user_agent'] # 4
            accept_language = site['url_rewrite'][i]['accept_language'] # 5

            province = ".*"
            if "province" in site['url_rewrite'][i]:
                province = site['url_rewrite'][i]['province'] # 6

            city = ".*"
            if "city" in site['url_rewrite'][i]:
                city = site['url_rewrite'][i]['city'] # 7

            isp = ".*"
            if "isp" in site['url_rewrite'][i]:
                isp = site['url_rewrite'][i]['isp'] # 8
            
            asnumber = ".*"
            if "asnumber" in site['url_rewrite'][i]:
                asnumber = site['url_rewrite'][i]['asnumber'] # 9

        # 白名单
        white_ip = site['white_ip']
        if white_ip:
            site['white_ip'] = white_ip.replace("\n",' ')

        # 把源ip加到白名单
        backend_ip = []
        backend = json.loads(site['backend'])
        for i in range(len(backend)):
            if backend[i]['state'] == "up":
                backend[i]['state'] = ""

            backend_addr = backend[i]['addr']
            if is_ip(backend_addr):
                if is_ipv6(backend_addr):
                    backend[i]['addr'] = "[" + backend_addr + "]"

                backend_ip.append(backend_addr)

        site['white_ip'] = site['white_ip'] + " " + " ".join(backend_ip)

        # 黑名单 
        black_ip = site['black_ip']
        if black_ip:
            site['black_ip'] = black_ip.replace("\n",' ')

        # acl
        if not site['acl']:
            site['acl'] = ""
        
        # 分离通配符域名
        non_wildcard_domain = []
        wildcard_domain = []

        for d in site['domain'].split():
            if d.find("*.") > -1:
                wildcard_domain.append(d)
            else:
                non_wildcard_domain.append(d)

        site['non_wildcard_domain'] = " ".join(non_wildcard_domain)
        site['wildcard_domain'] = wildcard_domain

        # cc_switch
        cc_switch = json.loads(site['cc_switch'])
        site['cc_switch'] = cc_switch
        site['cc_auto_switch_json'] = json.dumps(cc_switch)

        # health_check
        health_check_list = []
        health_check = json.loads(site['health_check'])
        if health_check['enable'] and len(backend) > 1:
            site['health_check'] = health_check
            ## 确定health check的upstream
            backend_port_mapping = site['backend_port_mapping']
            backend_protocol = site['backend_protocol']
            http_listen = site['http_listen']
            https_listen = site['https_listen']
            backend_http_port = site['backend_http_port']
            backend_https_port = site['backend_https_port']
            status_code = [int(i) for i in  site['health_check']['status_code'].split()]
            interval =  site['health_check']['interval']
            host = site['health_check']['host']
            path = site['health_check']['path']
            if backend_port_mapping:
                # 先看http有没有监听
                if http_listen:
                    for p in http_listen['port'].split():
                        upstream = "http_{id}_{backend_port}".format(id=site['id'],backend_port=p)
                        health_check_list.append({"enable":1,"protocol":"http","status_code":status_code,"interval": interval, "host": host, "upstream": upstream, "path": path})

                if https_listen:
                    for p in https_listen['port'].split():
                        upstream = "https_{id}_{backend_port}".format(id=site['id'],backend_port=p)
                        health_check_list.append({"enable":1,"protocol":"https","status_code":status_code,"interval": interval, "host": host, "upstream": upstream, "path": path})
            else:
                if backend_protocol == "http":
                    upstream = "http_{id}_{backend_port}".format(id=site['id'],backend_port=backend_http_port)
                    health_check_list.append({"enable":1,"protocol":"http","status_code":status_code,"interval": interval, "host": host, "upstream": upstream, "path": path})

                elif backend_protocol == "https":
                    upstream = "https_{id}_{backend_port}".format(id=site['id'],backend_port=backend_https_port)
                    health_check_list.append({"enable":1,"protocol":"https","status_code":status_code,"interval": interval, "host": host, "upstream": upstream, "path": path})

                elif backend_protocol == "follow":
                    if http_listen:
                        upstream = "http_{id}_{backend_port}".format(id=site['id'],backend_port=backend_http_port)
                        health_check_list.append({"enable":1,"protocol":"http","status_code":status_code,"interval": interval, "host": host, "upstream": upstream, "path": path})
                    
                    if https_listen:
                        upstream = "https_{id}_{backend_port}".format(id=site['id'],backend_port=backend_https_port)
                        health_check_list.append({"enable":1,"protocol":"https","status_code":status_code,"interval": interval, "host": host, "upstream": upstream, "path": path})


        # extra_cc_rule
        cc_rule = []
        extra_cc_rule = json.loads(site['extra_cc_rule'])
        for r in extra_cc_rule:
            matcher = r['matcher']
            filter1 = r['filter']

            rule = {"matcher":matcher, "matcher_name":"custom-cc-rule", 
                    "filter1":filter1,
                    "filter1_name":"custom-cc-rule", "filter2":"", "filter2_name":"",
                    "action":"ipset", "state":True}
            cc_rule.append(rule)

        conn = Db()
        rule_mix = {}
        try:
            # 指定的
            rule_default = cc_rule + json.loads(conn.fetchone("select data from cc_rule where id=%s", site['cc_default_rule'])['data'])
            rule_mix[site['cc_default_rule']] = rule_default

            # 宽松模式
            rule_6 = cc_rule + json.loads(conn.fetchone("select data from cc_rule where id=6")['data'])
            rule_mix["6"] = rule_6

            # 指定的切换
            if cc_switch:
                rule_switch = cc_rule + json.loads(conn.fetchone("select data from cc_rule where id=%s",cc_switch['rule'])['data'])
                rule_mix[cc_switch['rule']] = rule_switch

            # 系统指定的切换
            if site['cc_default_rule'] == "6" and not cc_switch:
                rule_id = json.loads(conn.fetchone("select value from config where name='openresty-config' and type='openresty_config' ")['value'])['auto_switch']['rule']
                rule_switch_sys = cc_rule + json.loads(conn.fetchone("select data from cc_rule where id=%s",rule_id)['data'])
                rule_mix[rule_id] = rule_switch_sys


        finally:
            conn.close()

        site['extra_cc_rule'] = extra_cc_rule
        site['extra_cc_rule_json'] = {}
        if extra_cc_rule:
            site['extra_cc_rule_json'] = rule_mix

        # hotlink
        hotlink = json.loads(site['hotlink'])
        hotlink_scope_type = hotlink['scope_type']
        hotlink_scope_content = hotlink['scope_content']

        uri = ""
        if hotlink_scope_type == "suffix":
            hotlink_scope_content = escape_re_str(hotlink_scope_content)
            uri = "\.({hotlink_scope_content})$".format(hotlink_scope_content=hotlink_scope_content)

        elif hotlink_scope_type == "dir":
            # 转义正则字符及分号,只保留通配符功能
            hotlink_scope_content = escape_re_str(hotlink_scope_content)
            hotlink_scope_content = hotlink_scope_content.replace(";","\;")
            hotlink_scope_content = hotlink_scope_content.replace('\\*','.*?')   
            uri = "^(" + hotlink_scope_content + ")"

        elif hotlink_scope_type == "full_path":
            # 转义正则字符及分号,只保留通配符功能
            hotlink_scope_content = escape_re_str(hotlink_scope_content)
            hotlink_scope_content = hotlink_scope_content.replace(";","\;")
            hotlink_scope_content = hotlink_scope_content.replace('\\*','.*?')
            uri = "^{hotlink_scope_content}$".format(hotlink_scope_content=hotlink_scope_content)    

        # 允许|
        uri = uri.replace('\\|','|')
        hotlink['scope_content'] = uri

        # domain处理，给防盗链查找域名用
        contain_wildcard = False
        domain_dict = {}
        for d in site['domain'].split():
            domain_dict[d] = 1
            if d.startswith("*"):
                contain_wildcard = True

        for d in hotlink['domain'].split():
            domain_dict[d] = 1
            if d.startswith("*"):
                contain_wildcard = True

        hotlink['domain_dict'] = domain_dict
        hotlink['contain_wildcard'] = contain_wildcard
        site['hotlink'] = hotlink

        # 如果开启回源端口映射，强制设置回源协议为跟随，回源端口为$server_port
        upstream_http_port = []
        upstream_https_port = []
        if site['backend_port_mapping']:
            site['backend_http_port'] = "$server_port"
            site['backend_https_port'] = "$server_port"
            site['backend_protocol'] = "follow"

            if site['http_listen']:
                upstream_http_port = site['http_listen']['port'].split()

            if site['https_listen']:
                upstream_https_port = site['https_listen']['port'].split()

        else:
            upstream_http_port = [site['backend_http_port']]
            upstream_https_port = [site['backend_https_port']]

        site['upstream_http_port'] = upstream_http_port
        site['upstream_https_port'] = upstream_https_port

        # 生成upstreams {"http_3_80":[{"ip":"127.0.0.1:80","weight":2,"state":"up"}]}
        backend_protocol = site['backend_protocol']
        upstream_data = {}
        http_listen = site['http_listen']
        https_listen = site['https_listen']
        backend = json.loads(site['backend'])
        if site['backend_port_mapping']:
            if http_listen:
                for p in http_listen['port'].split():
                    port_key = "http_{site_id}_{port}".format(site_id=site['id'], port=p)
                    if port_key not in upstream_data:
                        upstream_data[port_key] = []

                    for b in backend:
                        addr = b["addr"]
                        if is_ipv6(addr):
                            addr = "[" + addr + "]"

                        if b['state'] == "down":
                            continue

                        ip = "{ip}:{port}".format(ip=addr, port=p)
                        upstream_data[port_key].append({"ip":ip, "weight":b['weight'],"state":b['state'] })

            if https_listen:
                for p in https_listen['port'].split():
                    port_key = "https_{site_id}_{port}".format(site_id=site['id'], port=p)
                    if port_key not in upstream_data:
                        upstream_data[port_key] = []

                    for b in backend:
                        addr = b["addr"]
                        if is_ipv6(addr):
                            addr = "[" + addr + "]"

                        if b['state'] == "down":
                            continue

                        ip = "{ip}:{port}".format(ip=addr, port=p)
                        upstream_data[port_key].append({"ip":ip, "weight":b['weight'],"state":b['state'] })

        else:
            if backend_protocol in ["http","follow"]:
                backend_http_port = site['backend_http_port']
                port_key = "http_{site_id}_{port}".format(site_id=site['id'], port=backend_http_port)
                if port_key not in upstream_data:
                    upstream_data[port_key] = []

                for b in backend:
                    addr = b["addr"]
                    if is_ipv6(addr):
                        addr = "[" + addr + "]"    

                    if b['state'] == "down":
                        continue

                    ip = "{ip}:{port}".format(ip=addr, port=backend_http_port)
                    upstream_data[port_key].append({"ip":ip, "weight":b['weight'],"state":b['state'] })


            if backend_protocol in ["https","follow"]:
                backend_https_port = site['backend_https_port']
                port_key = "https_{site_id}_{port}".format(site_id=site['id'], port=backend_https_port)
                if port_key not in upstream_data:
                    upstream_data[port_key] = []

                for b in backend:
                    addr = b["addr"]
                    if is_ipv6(addr):
                        addr = "[" + addr + "]"

                    if b['state'] == "down":
                        continue

                    ip = "{ip}:{port}".format(ip=addr, port=backend_https_port)
                    upstream_data[port_key].append({"ip":ip, "weight":b['weight'],"state":b['state'] })

        backend_md5 = get_md5(json.dumps(upstream_data))

        # 转换block_region格式
        block_region = {}
        if site['block_region']:
            for r in site['block_region'].split(","):
                block_region[r] = 1

        # 处理upstream
        upstream = {"md5":backend_md5,"balance_way":site["balance_way"],"upstream":upstream_data}



        site_conf = {"state": str(site['state']),  "health_check_list":health_check_list, "id":str(site['id']), "version": site["version"], "backend_protocol": site["backend_protocol"], "upstream_http_port": site["upstream_http_port"], "balance_way": site["balance_way"], 
                "backend": site["backend"], "ups_keepalive": site["ups_keepalive"], "ups_keepalive_conn": site["ups_keepalive_conn"], "ups_keepalive_timeout": site["ups_keepalive_timeout"],
                "cc_default_rule": str(site["cc_default_rule"]), "acl": site["acl"], "uid": site["uid"], "user_package": site["user_package"], "block_proxy": site["block_proxy"],
                "https_listen": site["https_listen"], "spider_allow": site["spider_allow"], "http_listen": site["http_listen"], "is_default_server": site["is_default_server"],
                "proxy_ssl_protocols": site["proxy_ssl_protocols"], "acme_proxy_to_orgin": site["acme_proxy_to_orgin"], "send_real_time": site["send_real_time"], "recv_real_time": site["recv_real_time"],
                    "post_size_limit": site["post_size_limit"], "backend_port_mapping": site["backend_port_mapping"], "backend_http_port": site["backend_http_port"], "backend_https_port": site["backend_https_port"],
                    "cors": site["cors"], "range": site["range"], "backend_host": site["backend_host"], "proxy_timeout": site["proxy_timeout"], "proxy_connect_timeout": site["proxy_connect_timeout"], "websocket_enable": site["websocket_enable"], 
                    "ups_keepalive": site["ups_keepalive"], "proxy_http_version": site["proxy_http_version"], "req_header": site["req_header"], "cache": site["cache"], "hotlink": site["hotlink"],
                    "resp_header": site["resp_header"], "page_404": site["page_404"], "page_403": site["page_403"], "page_500": site["page_500"], "page_502": site["page_502"], "page_504": site["page_504"], "url_rewrite": site["url_rewrite"], "gzip_types": site["gzip_types"], 
                    "gzip_enable": site["gzip_enable"], "domain": site["domain"]}

        # 保存网站
        with open("/opt/cdnfly/master/agent/site/" + str(site['id']) + ".json","w") as fp:
            site_conf_json = json.dumps(site_conf)
            fp.write(site_conf_json)

        # 保存upstream
        with open("/opt/cdnfly/master/agent/site/" + str(site['id']) + ".ups","w") as fp:
            upstream_json = json.dumps(upstream)
            fp.write(upstream_json)

        return json.dumps({"site_conf":base64.b64encode(site_conf_json),"upstream":upstream, "black_ip":site['black_ip'],"white_ip":site['white_ip'],"extra_cc_rule_json":site['extra_cc_rule_json'],"cc_auto_switch_json":site['cc_auto_switch_json'],"block_region":block_region})
        

    def render_stream(stream):
        # backend
        backend = json.loads(stream['backend'])
        for i in range(len(backend)):
            backend_addr = backend[i]['addr']
            if is_ipv6(backend_addr):
                backend[i]['addr'] = "[" + backend_addr + "]"

        # 生成upstream
        upstream_data = []
        backend = json.loads(stream['backend'])
        backend_port = stream['backend_port']
        for b in backend:
            addr = b["addr"]
            if is_ipv6(addr):
                addr = "[" + addr + "]"

            if b['state'] == "down":
                continue

            ip = "{ip}:{port}".format(ip=addr, port=backend_port)
            upstream_data.append({"ip":ip, "weight":b['weight'],"state":b['state'] })

        backend_md5 = get_md5(json.dumps(upstream_data))

        # 处理upstream
        upstream = {"md5":backend_md5,"balance_way":stream["balance_way"],"upstream":upstream_data}

        # 处理block_region
        block_region = stream['block_region']
        if block_region != "":
            block_region_dict = {}
            for k in block_region.split(","):
                block_region_dict[k] = 1
            
            block_region = block_region_dict

        stream_json = {"state":stream['state'], "block_region":block_region, "upstream":upstream, "id": stream['id'], "uid": stream['uid'],"user_package": stream['user_package'],"listen": json.loads(stream['listen']),"balance_way": stream['balance_way'],"proxy_protocol": stream['proxy_protocol'],
        "backend_port": stream['backend_port'],"backend": backend,"conn_limit": stream['conn_limit'],"acl": json.loads(stream['acl']),"version": stream['version']}

        return stream_json

    # 生成网站配置 数字.json 网站配置
    site_dir = "/opt/cdnfly/master/agent/site"
    if not os.path.exists(site_dir):
        os.makedirs(site_dir)

    sites = conn.fetchall("select s.*, s.id,s.version,sc.version as sc_version, sc.data as sc_data, sc.templ_md5 as sc_templ_md5, sc.site_id as sc_site_id from site s left join site_conf_cache sc on sc.site_id=s.id where enable=1")
    total_site = len(sites)
    pos = 0
    for site in sites:
        pos = pos + 1
        site_id = site['id']
        version = site['version']
        sc_site_id = site['sc_site_id']

        if os.path.exists(site_dir + "/" + str(site_id) + ".json"):
            continue

        # 开始渲染
        print "site_id:" + str(site_id) + " need render"
        sc_data = render_site(site)
        if sc_site_id:
            conn.execute("update site_conf_cache set version=%s, data=%s where site_id=%s ",(version,sc_data,site_id,) )
        else:
            conn.execute("insert into site_conf_cache values (%s, %s, %s) ", (site_id,version, sc_data ) )

        conn.commit()

        print "creating site config, current progress " + str(pos) + "/" + str(total_site)
        with open("/tmp/master_upgrade.log", "a+") as fp:
            "creating site config, current progress " + str(pos) + "/" + str(total_site)

    # 生成 数字.json 转发配置
    stream_dir = "/opt/cdnfly/master/agent/stream"
    if not os.path.exists(stream_dir):
        os.makedirs(stream_dir)

    streams = conn.fetchall("select * from stream where enable=1")
    total_stream = len(streams)
    pos = 0
    for stream in streams:
        pos = pos + 1
        stream_id = stream['id']
        if os.path.exists(stream_dir + "/" + str(stream_id) + ".json"):
            continue

        # 开始渲染
        print "stream_id:" + str(stream_id) + " rendering"
        sc_data = render_stream(stream)
        upstream = sc_data['upstream']

        # 保存upstream
        with open(stream_dir + "/" + str(stream_id) + ".ups", "w" ) as fp:
            fp.write(json.dumps(upstream))    

        # 保存stream配置
        with open(stream_dir + "/" + str(stream_id) + ".json", "w" ) as fp:
            fp.write(json.dumps(sc_data))

        print "creating stream config, current progress " + str(pos) + "/" + str(total_stream)
        with open("/tmp/master_upgrade.log", "a+") as fp:
            "creating stream config, current progress " + str(pos) + "/" + str(total_stream)

    listen_default_http_80 = conn.fetchone("select * from config where type='site' and name='listen-default-http-80'")['value']
    nodes = conn.fetchall("select id, region_id from node where pid=0")
    for node in nodes:
        node_id = node['id']
        region_id = node['region_id']
        node_dir = "/opt/cdnfly/master/agent/" + str(node_id) + "/"
        if not os.path.exists(node_dir):
            os.makedirs(node_dir)

        listen_80 = ""
        listen_other = ""
        http_port = []
        https_port = []

        sql = '''
            SELECT 
                id, http_listen, https_listen
            FROM
                site 
            WHERE
                region_id = %s and enable=1
        '''

        sites = conn.fetchall(sql, region_id)
        for site in sites:
            http_listen = site['http_listen']
            https_listen = site['https_listen']
            if http_listen:
                http_listen = json.loads(http_listen)
                if http_listen:
                    port = str(http_listen['port'])
                    http_port += port.split()
                    
            if https_listen:
                    https_listen = json.loads(https_listen)
                    if https_listen:
                        port = str(https_listen['port'])
                        https_port += port.split()

        # 去重
        https_port = list(set(https_port))
        http_port = list(set(http_port))

        listen_80 = ""
        # 生成listen_80配置
        if "80" in http_port:
            site = {"http_80_site_listen":True,"http_port":["80"],"https_port":[]}
            listen_80 = render_listen_conf(site)

        else:
            # 看config配置中是否配置了listen 80
            if listen_default_http_80 == "1":
                site = {"http_80_site_listen":False,"http_port":["80"],"https_port":[]}
                listen_80 = render_listen_conf(site)                        

        # 生成其它监听
        if "80" in http_port:
            http_port.remove("80")

        site = {"http_80_site_listen":False,"http_port":http_port,"https_port":https_port}
        listen_other = ""
        if http_port or https_port:
            listen_other = render_listen_conf(site)

        # 保存listen_80和listen_other
        with open(node_dir + "/listen_80.conf", "w" ) as fp:
            fp.write(listen_80)

        with open(node_dir + "/listen_other.conf", "w" ) as fp:
            fp.write(listen_other)



        # 生成nginx.conf
        nginx_conf_json = gen_config(conn, "nginx_config", "nginx-config-file", region_id, node_id)
        nginx_tpl_file = "/opt/cdnfly-master-v5.6.0/master/conf/nginx_global.tpl"
        with open(nginx_tpl_file) as fp:
            nginx_tpl = fp.read()

        template = Template(nginx_tpl)
        value = template.render(config=nginx_conf_json)
        value = value.replace("__NODE_ID__", str(node_id))
        with open(node_dir + "/nginx.conf", "w" ) as fp:
            fp.write(value)

        # error_page.json
        error_page_json = gen_config(conn, "error_page", "error-page", region_id, node_id)
        error400 = str(error_page_json['p400'])
        error403 = str(error_page_json['p403'])
        error502 = str(error_page_json['p502'])
        error504 = str(error_page_json['p504'])
        error512 = str(error_page_json['p512'])
        error513 = str(error_page_json['p513'])
        error514 = str(error_page_json['p514'])
        error515 = str(error_page_json['p515'])
        error_host_not_found = str(error_page_json['host_not_found'])
        error_access_ip_not_allow = str(error_page_json['access_ip_not_allow'])

        error_page_content = {"page_400": error400, "page_403":error403, "page_502": error502, "page_504": error504, "page_512": error512,"page_513": error513,
            "page_514": error514, "page_515": error515, "page_530": error_host_not_found, "access_ip_not_allow": error_access_ip_not_allow  }

        with open(node_dir + "/error_page.json", "w" ) as fp:
            fp.write(json.dumps(error_page_content)) 

        # resolver.txt
        openresty_json = gen_config(conn, "openresty_config", "openresty-config", region_id, node_id)
        resolver = openresty_json['resolver']
        with open(node_dir + "/resolver.txt", "w" ) as fp:
            fp.write(resolver)

        # stream_listen.conf
        sql = '''
            SELECT 
                id, listen
            FROM
                stream 
            WHERE
                region_id = %s and enable=1
        '''
        streams = conn.fetchall(sql, region_id)
        listens = []
        for stream in streams:
            listen = json.loads(stream['listen'])
            for l in listen:
                port = l['port']
                protocol = l['protocol']
                if protocol == "tcp": protocol = ""
                listens.append({"port":port,"protocol":protocol})


        tpl_file = "/opt/cdnfly-master-v5.6.0/master/conf/nginx_stream_listen.tpl"
        with open(tpl_file) as fp:
            tpl = fp.read()

        template = Template(tpl)
        stream_listen_conf = template.render(listens=listens)
        with open(node_dir + "/stream_listen.conf", "w" ) as fp:
            fp.write(stream_listen_conf)


        # 根据节点id打包 网站配置 生成upstream.json
        os.chdir("/opt/cdnfly/master/agent/site/")
        tar_name = node_dir + "site.tar"
        sites = conn.fetchall("SELECT  distinct site.id FROM site JOIN line ON line.node_group_id = site.node_group_id OR line.node_group_id = site.backup_node_group WHERE line.node_id = %s and site.enable=1 ", node_id )
        files_to_add = []
        upstream = {}
        for site in sites:
            site_id = site['id']
            files_to_add.append(str(site_id)+".json")

            with open("/opt/cdnfly/master/agent/site/" + str(site_id) + ".ups" ) as fp:
                upstream[str(site_id)] = json.loads(fp.read())

        # 保存upstream
        with open(node_dir + "/site-upstream.json","w") as fp:
            fp.write(json.dumps(upstream)) 

        # 保存site
        with tarfile.open(tar_name, "w") as tar:
            for file in files_to_add:
                tar.add(file)


        # 根据节点id 打包四层配置 生成upstream.json
        os.chdir("/opt/cdnfly/master/agent/stream/")
        tar_name = node_dir + "/stream.tar"
        streams = conn.fetchall("SELECT  distinct stream.id FROM stream JOIN line ON line.node_group_id = stream.node_group_id OR line.node_group_id = stream.backup_node_group WHERE line.node_id = %s and stream.enable=1", node_id )
        files_to_add = []
        upstream = {}
        for stream in streams:
            stream_id = stream['id']
            files_to_add.append(str(stream_id)+".json")

            with open("/opt/cdnfly/master/agent/stream/" + str(stream_id) + ".ups" ) as fp:
                upstream[str(stream_id)] = json.loads(fp.read())

        # 保存upstream
        with open(node_dir + "/stream-upstream.json","w") as fp:
            fp.write(json.dumps(upstream)) 

        # 保存stream
        with tarfile.open(tar_name, "w") as tar:
            for file in files_to_add:
                tar.add(file)



except:
    conn.rollback()
    raise

finally:
    conn.close()
EOF

/opt/venv/bin/python /tmp/_db.py



# 更新panel或conf
flist='master/panel/console/index.html
master/panel/src/views/config/default/index.html
master/panel/src/views/config/cc/index.html
master/panel/src/views/node/node/index.html
master/panel/src/views/site/site/edit.html
master/panel/src/views/system/config/index.html
master/panel/src/views/system/op/index.html
master/panel/src/views/user_config/site/addform.html
master/panel/src/views/site/monitor/access-log.html
master/panel/src/views/site/site/add_error_page.html
master/conf/nginx_global.tpl
master/conf/nginx_stream_listen.tpl
master/panel/src/views/config/nginx/index.html
master/panel/src/views/package/basic/addform.html
master/panel/src/views/package/basic/index.html
master/panel/src/views/package/basic/sync.html
master/panel/src/views/package/my/detail.html
master/panel/src/views/package/sold/detail.html
master/panel/src/views/package/sold/editform.html
master/panel/src/views/package/sold/index.html
master/panel/src/views/site/monitor/access-log.html
master/panel/src/views/site/site/index.html
master/panel/src/views/stream/stream/edit.html
master/panel/src/views/user_config/site/addform.html
master/panel/src/views/user_config/site/index.html
master/conf/nginx_http_default.tpl
master/panel/src/views/node/monitor/realtime.html'

for f in `echo $flist`;do
\cp -a /opt/$dir_name/$f /opt/cdnfly/$f
done


# 关闭维护模式
mysql -h$MYSQL_IP -u$MYSQL_USER -p$MYSQL_PASS -P$MYSQL_PORT $MYSQL_DB -e "update config set value='{\"enable\":0,\"msg\":\"系统升级中,请稍候重试\"}' where name='maintain' " 

}

update_file() {
cd /opt/$dir_name/master/
for i in `find ./ | grep -vE "^./$|^./agent$|^./conf$|conf/config.py|conf/nginx_global.tpl|conf/supervisord.conf|conf/supervisor_master.conf|conf/nginx_http_default.tpl|conf/nginx_http_vhost.tpl|conf/nginx_stream_vhost.tpl|conf/ssl.cert|conf/ssl.key|^./panel"`;do
    \cp -aT $i /opt/cdnfly/master/$i
done

}

# 定义版本
version_name="v5.6.0"
version_num="50600"
dir_name="cdnfly-master-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

cd /opt
echo "准备升级数据库..."
upgrade_db
echo "升级数据库完成"

echo "更新文件..."
update_file
echo "更新文件完成." 

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/master/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/master/conf/config.py
rm -f /opt/cdnfly/master/conf/config.pyc
echo "修改完成"

echo "开始重启主控..."
supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf restart all
# supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf reload
echo "重启完成"

echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"