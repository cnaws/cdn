#!/bin/bash

set -o errexit

download(){
  # wget安装
  if [[ ! `which wget` ]]; then
    if check_sys sysRelease ubuntu;then
        apt-get install -y wget
    elif check_sys sysRelease centos;then
        yum install -y wget
    fi 
  fi

  local url1=$1
  local url2=$2
  local filename=$3
  
  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url=$url1
  if [[ $speed2 -gt $speed1 ]]; then
    url=$url2
  fi
  echo "using url:"$url
  wget "$url" -O $filename

}

#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}

get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)','\g<1>',sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
if sys_ver.startswith("debian-11"):
    sys_ver = "debian-11"

if sys_ver.startswith("Ubuntu-16.04"):
    sys_ver = "Ubuntu-16.04"

if sys_ver.startswith("Ubuntu-22.04"):
    sys_ver = "Ubuntu-22.04"

print sys_ver
EOF
echo `python2 /tmp/sys_ver.py`
}


upgrade_db() {
supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf stop cc_auto_switch node_monitor site_res_count site_sync task

cd  /root/.acme.sh/dnsapi
ln -s /opt/cdnfly/master/conf/dns_com.sh || true

cd /tmp
download "https://dl2.cdnfly.cn/cdnfly/pymodule-master-20231014.tar.gz" "https://us.centos.bz/cdnfly/pymodule-master-20231014.tar.gz" "pymodule-master-20231014.tar.gz"
tar xf pymodule-master-20231014.tar.gz
cd pymodule-master-20231014
/opt/venv/bin/pip install jdcloud_sdk-1.6.246.tar.gz

cat > /tmp/_db.py <<'EOF'
# -*- coding: utf-8 -*-

import sys
sys.path.append("/opt/cdnfly/master/")
from model.db import Db
import pymysql
import json
reload(sys) 
import re
sys.setdefaultencoding('utf8')

conn = Db()
try:

    # 短信和邮件防刷
    if not conn.fetchone("select * from config where name='captcha_type' and type='system' "):
        conn.execute(''' insert into config values ('captcha_type','{"email":"","phone":"native"}','system','0','global', now(),now(),1,null) ''')
        conn.commit()

    if not conn.fetchone("select * from config where name='qcloud_captcha' and type='system' "):
        conn.execute(''' insert into config values ('qcloud_captcha','{}','system','0','global', now(),now(),1,null) ''')
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'captcha' AND column_name = 'img_code' "):
        conn.execute("alter table captcha add img_code varchar(10) after captcha")
        conn.commit()

    # 折扣和优惠码
    if not conn.fetchone("SHOW TABLES LIKE 'user_group'"):
        conn.execute("CREATE TABLE `user_group` (`id` INT(11) NOT NULL AUTO_INCREMENT,`name` VARCHAR(255),`des` VARCHAR(255),`create_at` DATETIME, PRIMARY KEY `id` (`id`))  ENGINE=INNODB DEFAULT CHARSET=UTF8MB4")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'user' AND column_name = 'user_group' "):
        conn.execute("alter table user add user_group int(11) after qq")
        conn.commit()

    if not conn.fetchone("SHOW TABLES LIKE 'discount'"):
        conn.execute("CREATE TABLE `discount` (`id` int(11) NOT NULL AUTO_INCREMENT,`name` varchar(255) DEFAULT NULL,`des` varchar(255) DEFAULT NULL,`user_group` varchar(255) DEFAULT NULL,`package` varchar(255) DEFAULT NULL,`dis_type` varchar(10) DEFAULT NULL,`discount_value` double(10,2) DEFAULT NULL,`month_price` bigint(20) DEFAULT NULL,`quarter_price` bigint(20) DEFAULT NULL,`year_price` bigint(20) DEFAULT NULL,`start_at` datetime DEFAULT NULL,`end_at` datetime DEFAULT NULL,`priority` int(11) DEFAULT '100',`enable` tinyint(1) DEFAULT NULL,`create_at` datetime DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'order' AND column_name = 'real_amount' "):
        conn.execute("alter table `order` add real_amount bigint(20) after amount")
        conn.execute("update `order` set real_amount=amount")
        conn.commit()

    if not conn.fetchone("SHOW TABLES LIKE 'coupon'"):
        conn.execute("CREATE TABLE `coupon` (`id` int(11) NOT NULL AUTO_INCREMENT,`name` varchar(255) DEFAULT NULL,`des` varchar(255) DEFAULT NULL,`code` varchar(30) DEFAULT NULL,`coupon_type` varchar(10) DEFAULT NULL,`price_gt` int(11) DEFAULT NULL,`discount_value` double(10,2) DEFAULT NULL,`price_value` int(11) DEFAULT NULL,`max_times` int(11) DEFAULT NULL,`used_times` int(11) DEFAULT NULL,`package` varchar(255) DEFAULT NULL,`start_at` datetime DEFAULT NULL,`end_at` datetime DEFAULT NULL,`enable` tinyint(1) DEFAULT NULL,`create_at` datetime DEFAULT NULL,PRIMARY KEY (`id`),KEY `code_idx` (`code`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
        conn.commit()    

    if not conn.fetchone("SHOW TABLES LIKE 'coupon_history'"):
        conn.execute("CREATE TABLE `coupon_history` (`id` bigint(20) NOT NULL AUTO_INCREMENT,`name` varchar(255) DEFAULT NULL,`des` varchar(255) DEFAULT NULL,`coupon_id` int(11) DEFAULT NULL,`code` varchar(30) DEFAULT NULL,`uid` int(11) DEFAULT NULL,`package_id` int(11) DEFAULT NULL,`user_package_id` int(11) DEFAULT NULL,`package_name` varchar(255) DEFAULT NULL,`orgin_price` int(11) DEFAULT NULL,`real_price` int(11) DEFAULT NULL,`coupon_type` varchar(10) DEFAULT NULL,`coupon_price_gt` int(11) DEFAULT NULL,`discount_value` double(10,2) DEFAULT NULL,`price_value` int(11) DEFAULT NULL,`create_at` datetime DEFAULT NULL,PRIMARY KEY (`id`),KEY `code_idx` (`code`),KEY `coupon_id_idx` (`coupon_id`),KEY `uid_id_idx` (`uid`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;")
        conn.commit()    

    # 节点和线路组排序
    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'node' AND column_name = 'sort' "):
        conn.execute("alter table node add sort int(11) default 100")
        conn.commit()

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'node_group' AND column_name = 'sort' "):
        conn.execute("alter table node_group add sort int(11) default 100")
        conn.commit()

    # node的config_task改text
    conn.execute("alter table node modify config_task text")
    conn.commit()

    # 更新spider ip
    openresty_config = json.loads(conn.fetchone("select value from config where name='openresty-config'  and scope_name='global' ")['value'])
    openresty_config['spider_ip'] = {"40.77.195": 1, "40.77.194": 1, "40.77.191": 1, "40.77.190": 1, "40.77.193": 1, "40.77.192": 1, "34.89.10": 1, "154.12.224.26": 1, "220.243.189": 1, "220.243.188": 1, "40.77.168": 1, "40.77.169": 1, "40.77.160": 1, "123.183.224": 1, "40.77.162": 1, "40.77.163": 1, "40.77.164": 1, "40.77.165": 1, "40.77.166": 1, "40.77.167": 1, "34.88.194": 1, "20.36.108": 1, "34.65.242": 1, "217.156.87.14": 1, "157.55.50": 1, "40.90.149": 1, "40.90.148": 1, "40.90.147": 1, "40.90.146": 1, "40.90.145": 1, "40.90.144": 1, "65.55.230.252": 1, "51.4.84": 1, "65.55.230.250": 1, "40.77.223": 1, "40.77.222": 1, "40.77.221": 1, "40.77.220": 1, "34.64.82": 1, "218.30.103": 1, "23.103.64": 1, "65.54.164": 1, "207.68.185.33": 1, "40.77.161": 1, "199.30.28": 1, "106.11.157": 1, "106.11.156": 1, "106.11.155": 1, "106.11.154": 1, "106.11.153": 1, "106.11.152": 1, "207.46.13": 1, "193.234.60.18": 1, "106.11.159": 1, "106.11.158": 1, "109.238.6.49": 1, "109.238.6.46": 1, "61.135.158.81": 1, "220.243.136": 1, "220.243.135": 1, "40.79.186": 1, "217.156.87.5": 1, "110.249.201": 1, "110.249.202": 1, "131.253.46.111": 1, "106.120.188.69": 1, "40.90.11": 1, "42.120.236": 1, "42.159.48": 1, "34.154.114": 1, "199.30.30": 1, "199.30.31": 1, "202.89.235": 1, "111.206.221": 1, "42.120.161": 1, "104.44.93": 1, "104.44.92": 1, "104.44.91": 1, "64.4.22": 1, "36.110.147.71": 1, "36.110.147.70": 1, "157.55.154": 1, "42.236.46": 1, "157.56.93": 1, "123.125.125.179": 1, "42.236.49": 1, "65.55.189": 1, "199.188.107.107": 1, "131.253.35": 1, "157.56.71": 1, "34.146.150": 1, "61.135.169.52": 1, "61.135.169.53": 1, "178.20.236": 1, "61.135.168": 1, "113.24.225": 1, "40.77.253": 1, "40.77.186": 1, "40.77.187": 1, "40.77.184": 1, "40.77.185": 1, "40.77.182": 1, "40.77.183": 1, "40.77.180": 1, "40.77.181": 1, "40.77.188": 1, "40.77.189": 1, "42.236.101": 1, "42.236.102": 1, "42.236.103": 1, "20.74.197": 1, "61.135.169.19": 1, "34.118.254": 1, "20.15.133": 1, "207.46.126": 1, "65.52.109": 1, "131.253.46.223": 1, "157.56.2": 1, "157.56.3": 1, "157.56.0": 1, "157.56.1": 1, "20.43.120": 1, "34.100.182": 1, "40.77.248": 1, "40.90.150": 1, "40.90.151": 1, "40.90.152": 1, "40.90.153": 1, "40.90.154": 1, "40.90.155": 1, "40.90.156": 1, "40.90.157": 1, "40.90.158": 1, "42.120.234": 1, "42.120.235": 1, "111.221.28": 1, "61.135.165.19": 1, "49.7.116": 1, "49.7.117": 1, "40.90.8": 1, "207.68.176.142": 1, "207.68.176.141": 1, "118.184.177": 1, "66.249.79": 1, "66.249.78": 1, "66.249.71": 1, "66.249.70": 1, "66.249.73": 1, "66.249.72": 1, "66.249.75": 1, "66.249.74": 1, "66.249.77": 1, "66.249.76": 1, "191.232.136.48": 1, "60.8.123": 1, "180.76.15": 1, "191.232.136.172": 1, "43.231.99": 1, "207.68.146.215": 1, "61.135.159": 1, "131.253.46.125": 1, "131.253.46.126": 1, "35.247.243": 1, "34.165.18": 1, "65.54.247": 1, "40.66.1": 1, "180.153.232": 1, "40.66.4": 1, "51.5.84": 1, "34.175.160": 1, "123.125.186.11": 1, "123.125.186.12": 1, "34.152.50": 1, "40.77.209": 1, "40.77.208": 1, "42.159.176": 1, "220.181.108": 1, "65.55.230.225": 1, "61.135.165.53": 1, "103.255.141": 1, "42.236.48": 1, "154.12.224.161": 1, "157.55.39": 1, "191.232.136.86": 1, "65.55.230.253": 1, "180.76.5": 1, "36.110.147.68": 1, "36.110.147.69": 1, "193.234.60.17": 1, "40.77.210": 1, "111.206.198": 1, "36.110.147.64": 1, "36.110.147.65": 1, "36.110.147.66": 1, "36.110.147.67": 1, "42.120.160": 1, "192.178.5": 1, "123.126.113": 1, "131.253.36": 1, "42.236.99": 1, "103.25.156": 1, "123.125.125.184": 1, "131.253.38": 1, "123.125.125.181": 1, "123.125.125.182": 1, "40.79.131": 1, "61.135.169.20": 1, "34.155.98": 1, "61.135.165.20": 1, "65.55.107": 1, "131.253.46.221": 1, "131.253.46.224": 1, "191.232.136.216": 1, "34.147.110": 1, "49.7.21": 1, "49.7.20": 1, "180.153.234": 1, "180.153.236": 1, "207.68.146.222": 1, "207.68.146.221": 1, "111.225.148": 1, "111.225.149": 1, "65.55.219": 1, "65.55.218": 1, "65.55.213": 1, "65.55.212": 1, "65.55.211": 1, "65.55.210": 1, "65.55.217": 1, "65.55.216": 1, "65.55.215": 1, "65.55.214": 1, "199.30.17": 1, "199.30.18": 1, "199.30.19": 1, "203.208.60": 1, "123.125.66": 1, "199.30.26": 1, "191.233.204": 1, "40.77.252": 1, "106.38.241": 1, "40.77.250": 1, "40.77.251": 1, "180.149.133": 1, "40.77.254": 1, "40.77.255": 1, "111.221.31": 1, "180.163.220": 1, "13.66.144": 1, "116.179.32": 1, "66.249.69": 1, "124.166.232": 1, "116.179.37": 1, "106.120.173": 1, "66.249.66": 1, "66.249.64": 1, "66.249.65": 1, "65.55.146": 1, "111.202.101": 1, "123.125.125.151": 1, "111.202.100": 1, "61.135.189": 1, "60.8.151": 1, "42.236.16": 1, "51.105.67": 1, "64.68.88": 1, "42.236.15": 1, "42.236.14": 1, "207.68.155": 1, "65.52.110": 1, "42.156.255": 1, "42.156.254": 1, "61.135.186": 1, "40.77.177": 1, "40.77.176": 1, "40.77.175": 1, "40.77.174": 1, "40.77.173": 1, "40.77.172": 1, "40.77.171": 1, "40.77.170": 1, "40.77.179": 1, "40.77.178": 1, "40.77.216": 1, "40.77.217": 1, "40.77.214": 1, "40.77.215": 1, "40.77.212": 1, "40.77.213": 1, "34.126.178": 1, "40.77.211": 1, "40.77.218": 1, "40.77.219": 1, "34.176.130": 1, "61.49.160.21": 1, "61.49.160.20": 1, "42.236.50": 1, "194.32.107.227": 1, "194.32.107.226": 1, "154.53.40.69": 1, "154.53.40.63": 1, "42.236.17": 1, "157.55.21": 1, "157.55.22": 1, "157.55.23": 1, "42.236.13": 1, "42.236.12": 1, "42.236.10": 1, "34.118.66": 1, "34.80.50": 1, "65.55.25": 1, "104.44.253": 1, "207.68.185.56": 1, "123.126.68": 1, "131.253.47.190": 1, "34.89.198": 1, "207.46.199": 1, "131.253.25": 1, "131.253.24": 1, "131.253.27": 1, "131.253.26": 1, "157.55.2": 1, "157.55.7": 1, "42.156.138": 1, "42.156.139": 1, "52.167.144": 1, "42.156.137": 1, "40.73.148": 1, "157.55.103": 1, "58.250.125": 1, "157.55.106": 1, "157.55.107": 1, "207.46.12.79": 1, "207.46.12.78": 1, "207.46.12.75": 1, "207.46.12.74": 1, "207.46.12.77": 1, "207.46.12.76": 1, "207.46.12.73": 1, "207.46.12.72": 1, "154.53.40.3": 1, "154.53.40.2": 1, "20.79.107": 1, "65.55.208": 1, "65.55.209": 1, "34.96.162": 1, "106.120.188.72": 1, "106.120.188.73": 1, "106.120.188.70": 1, "106.120.188.71": 1, "106.120.188.76": 1, "106.120.188.74": 1, "106.120.188.75": 1, "61.135.165.52": 1, "123.125.71": 1, "123.125.109": 1, "220.181.32": 1, "111.202.103": 1, "220.181.124": 1, "220.181.125": 1, "104.47.224": 1, "199.30.29": 1, "13.71.172": 1, "199.30.23": 1, "199.30.22": 1, "199.30.21": 1, "199.30.20": 1, "199.30.27": 1, "61.49.160.19": 1, "199.30.25": 1, "199.30.24": 1, "34.101.50": 1, "207.68.176.163": 1, "207.68.176.164": 1, "157.55.10": 1, "157.55.13": 1, "157.55.12": 1, "123.125.186.10": 1, "34.22.85.0": 1, "34.22.85.1": 1, "34.22.85.2": 1, "34.22.85.3": 1, "34.22.85.4": 1, "34.22.85.5": 1, "34.22.85.6": 1, "34.22.85.7": 1, "34.151.74": 1, "65.55.54": 1, "123.126.50": 1, "42.236.53": 1, "42.236.52": 1, "42.236.51": 1, "131.253.47.148": 1, "42.236.55": 1, "42.236.54": 1, "131.253.47.147": 1, "199.188.107.110": 1, "64.68.92": 1, "64.68.91": 1, "64.68.90": 1, "61.135.158.72": 1, "66.249.68": 1, "109.238.6.19": 1, "42.156.136": 1}

    conn.execute("update config set value=%s where name='openresty-config'  and scope_name='global' ",json.dumps(openresty_config))
    conn.commit()

    # user dns api
    if not conn.fetchone("SHOW TABLES LIKE 'domain'"):
        conn.execute("create table domain (`id` int(11) not null auto_increment,`site_id` int(11),`domain` varchar(255),`record_id` varchar(255),`task_id` bigint,primary KEY `id` (`id`),index site_id_idx(`site_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4")
        
        # 填数据
        sites = conn.fetchall("select id, domain from site")
        for site in sites:
            domain = site['domain']
            for d in domain.split():
                conn.execute("insert into domain values (null,%s, %s, null,null) ",(site['id'], d, ) )
                
        conn.commit()    

    if not conn.fetchone("SELECT column_name FROM information_schema.columns WHERE table_name = 'site' AND column_name = 'dns_api' "):
        conn.execute("alter table site add dns_api int(11) after src_hostname")
        conn.commit()


except:
    conn.rollback()
    raise

finally:
    conn.close()
EOF

/opt/venv/bin/python /tmp/_db.py

# 更新panel或conf
flist='master/panel/console/index.html
master/panel/console/user_menu.json
master/panel/src/views/account/personal/index.html
master/panel/src/views/config/cc/index.html
master/panel/src/views/config/error/index.html
master/panel/src/views/config/res/index.html
master/panel/src/views/finance/order/addform.html
master/panel/src/views/finance/order/index.html
master/panel/src/views/node/group/groupform.html
master/panel/src/views/node/group/index.html
master/panel/src/views/node/node/index.html
master/panel/src/views/node/node/nodeform.html
master/panel/src/views/package/buy/duration.html
master/panel/src/views/package/buy/index.html
master/panel/src/views/package/sold/index.html
master/panel/src/views/site/acl/index.html
master/panel/src/views/site/cc/match-add.html
master/panel/src/views/site/cc/matchlist-add.html
master/panel/src/views/site/cert/cert.html
master/panel/src/views/site/cert/dnsapi-add.html
master/panel/src/views/site/cert/dnsapi.html
master/panel/src/views/site/refresh/index.html
master/panel/src/views/site/site/addform.html
master/panel/src/views/site/site/cache_form.html
master/panel/src/views/site/site/edit.html
master/panel/src/views/site/site/index.html
master/panel/src/views/site/site/update_form.html
master/panel/src/views/site/site/url_ratelimit_form.html
master/panel/src/views/system/config/index.html
master/panel/src/views/system/user/addform.html
master/panel/src/views/system/user/index.html
master/panel/src/views/user/forget.html
master/panel/src/views/user/login.html
master/panel/src/views/user/reg.html
master/panel/src/views/user_config/cert/index.html
master/panel/src/views/user_config/site/addform.html
master/panel/src/views/user_config/site/index.html
master/panel/src/views/package/coupon/
master/panel/src/views/package/discount/
master/panel/src/views/site/domain/
master/panel/src/views/system/user-group/
master/conf/nginx_global.tpl
master/conf/dns_com.sh'

for f in `echo $flist`;do
\cp -a /opt/$dir_name/$f /opt/cdnfly/$f
done

}

update_file() {
cd /opt/$dir_name/master/
for i in `find ./ | grep -vE "^./$|^./agent$|^./conf$|conf/config.py|conf/nginx_global.tpl|conf/supervisord.conf|conf/supervisor_master.conf|conf/nginx_http_default.tpl|conf/nginx_http_vhost.tpl|conf/nginx_stream_vhost.tpl|conf/ssl.cert|conf/ssl.key|^./panel"`;do
    \cp -aT $i /opt/cdnfly/master/$i
done

}

# 定义版本
version_name="v5.5.0"
version_num="50500"
dir_name="cdnfly-master-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://dl2.cdnfly.cn/cdnfly/$tar_gz_name" "https://us.centos.bz/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

cd /opt
echo "准备升级数据库..."
upgrade_db
echo "升级数据库完成"

echo "更新文件..."
update_file
echo "更新文件完成." 

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/master/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/master/conf/config.py
rm -f /opt/cdnfly/master/conf/config.pyc
echo "修改完成"

echo "开始重启主控..."
supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf restart all
#supervisorctl  -c /opt/cdnfly/master/conf/supervisord.conf reload
echo "重启完成"

echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"