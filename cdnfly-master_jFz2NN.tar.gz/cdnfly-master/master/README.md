# virutalenv环境制作

pip install virtualenv

cd /opt/cdnfly/master
virtualenv venv
cd venv
source bin/activate

pip install Flask
pip install PyMySQL
pip install Pillow
pip install pycryptodome
pip install bcrypt
pip install pyOpenSSL
pip install python_dateutil
pip install aliyun-python-sdk-core
pip install aliyun-python-sdk-alidns
pip install qcloudapi-sdk-python
pip install requests
pip install psutil
pip install dnspython
pip install Flask-Compress
pip install supervisor
pip install APScheduler
pip install gunicorn
pip install gevent
pip install python_daemon

